// Optimise les photos de public/images :
//  - convertit chaque JPEG/PNG en WebP compressé et redimensionné
//  - génère un aperçu flou minuscule (src/lib/image-blur.json) affiché pendant le chargement
// Usage : node scripts/optimize-images.mjs   (ajoutez vos nouvelles photos en .jpg/.png puis relancez)
import { readdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

const dir = path.resolve("public/images");
const files = (await readdir(dir)).filter((f) => /\.(jpe?g|png)$/i.test(f));
const blur = {};

for (const file of files) {
  const input = path.join(dir, file);
  const name = file.replace(/\.(jpe?g|png)$/i, "");
  const out = path.join(dir, `${name}.webp`);
  const maxWidth = name === "hero" ? 1920 : 1400;

  await sharp(input)
    .rotate()
    .resize({ width: maxWidth, withoutEnlargement: true })
    .webp({ quality: 66, effort: 6, smartSubsample: true })
    .toFile(out);

  await unlink(input);
  console.log(`✓ ${file} → ${name}.webp`);
}

// Aperçus flous pour toutes les images WebP
for (const file of (await readdir(dir)).filter((f) => f.endsWith(".webp"))) {
  const buf = await sharp(path.join(dir, file)).resize(16).webp({ quality: 40 }).toBuffer();
  blur[`/images/${file}`] = `data:image/webp;base64,${buf.toString("base64")}`;
}
await writeFile(path.resolve("src/lib/image-blur.json"), JSON.stringify(blur, null, 2) + "\n");
console.log(`✓ ${Object.keys(blur).length} aperçus flous générés`);
