import Link from "next/link";

export default function NotFound() {
  return (
    <section className="mx-auto flex min-h-[80vh] max-w-[1600px] flex-col justify-center px-5 pt-32 pb-24 md:px-10">
      <p className="numeral text-sm text-moss">404</p>
      <h1 className="font-display mt-4 text-[clamp(2.8rem,7vw,6rem)] leading-[0.95]">
        Cette adresse <em className="italic">n&apos;existe pas.</em>
      </h1>
      <p className="mt-6 max-w-md text-moss">
        Le bien a peut-être été vendu ou loué. Découvrez les biens actuellement proposés par l&apos;agence.
      </p>
      <div className="mt-10 flex flex-wrap gap-6">
        <Link href="/biens" className="bg-olive px-7 py-4 text-[0.75rem] tracking-[0.16em] text-chalk uppercase hover:bg-ink">
          Voir les biens
        </Link>
        <Link href="/" className="self-center text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
          Accueil
        </Link>
      </div>
    </section>
  );
}
