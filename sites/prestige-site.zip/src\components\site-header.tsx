"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState, ViewTransition } from "react";
import { Wordmark } from "@/components/wordmark";
import { agency } from "@/lib/agency";
import { cn } from "@/lib/cn";

const nav = [
  { href: "/biens", label: "Biens", index: "01" },
  { href: "/agence", label: "L'agence", index: "02" },
  { href: "/#expertise", label: "Expertise", index: "03" },
  { href: "/contact", label: "Contact", index: "04" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let last = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      setHidden(y > 240 && y > last + 2);
      if (y < last - 2) setHidden(false);
      last = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Fermer le menu à chaque navigation
  const [prevPath, setPrevPath] = useState(pathname);
  if (prevPath !== pathname) {
    setPrevPath(pathname);
    setOpen(false);
  }

  useEffect(() => {
    document.documentElement.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const overlay = pathname === "/" && !scrolled && !open;
  const isActive = (href: string) => !href.includes("#") && pathname.startsWith(href);

  return (
    <ViewTransition name="site-header">
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-[transform,background-color,color,border-color] duration-500 ease-[var(--ease-out-soft)]",
          hidden && !open ? "-translate-y-full" : "translate-y-0",
          overlay
            ? "border-b border-transparent text-chalk"
            : open
              ? "border-b border-transparent text-chalk"
              : "border-b border-line bg-chalk/92 text-ink backdrop-blur-md",
        )}
      >
        <div className="mx-auto flex h-[4.5rem] max-w-[1600px] items-center justify-between px-5 md:h-20 md:px-10">
          <Link href="/" aria-label={`${agency.name} — accueil`} className="relative z-[60]">
            <Wordmark />
          </Link>

          <nav aria-label="Navigation principale" className="hidden lg:block">
            <ul className="flex items-center gap-10">
              {nav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={cn(
                      "group relative flex items-baseline gap-1.5 text-[0.8125rem] tracking-wide",
                    )}
                    aria-current={isActive(item.href) ? "page" : undefined}
                  >
                    <span className="numeral text-[0.7rem] opacity-50">{item.index}</span>
                    <span className="link-underline pb-0.5" style={isActive(item.href) ? { backgroundSize: "100% 1px" } : undefined}>
                      {item.label}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-5">
            <a
              href={`tel:${agency.phones[1].tel}`}
              className="hidden text-[0.8125rem] tabular-nums tracking-wide md:inline link-underline"
            >
              +216 {agency.phones[1].display}
            </a>
            <Link
              href="/contact?objet=estimation"
              className={cn(
                "hidden border px-5 py-2.5 text-[0.75rem] tracking-[0.14em] uppercase transition-colors duration-300 lg:inline-block",
                overlay
                  ? "border-chalk/50 hover:bg-chalk hover:text-ink"
                  : "border-ink/30 hover:border-ink hover:bg-ink hover:text-chalk",
              )}
            >
              Estimer mon bien
            </Link>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="menu-mobile"
              className="relative z-[60] flex h-10 items-center gap-3 lg:hidden"
            >
              <span className="eyebrow">{open ? "Fermer" : "Menu"}</span>
              <span className="relative block h-3 w-6" aria-hidden>
                <span
                  className={cn(
                    "absolute left-0 h-px w-full bg-current transition-transform duration-500",
                    open ? "top-1.5 rotate-45" : "top-0",
                  )}
                />
                <span
                  className={cn(
                    "absolute left-0 h-px w-full bg-current transition-transform duration-500",
                    open ? "top-1.5 -rotate-45" : "top-3",
                  )}
                />
              </span>
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="menu-mobile"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            className="grain fixed inset-0 z-40 flex flex-col overflow-y-auto bg-olive px-5 pt-28 pb-10 text-chalk md:px-10 lg:hidden"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.7, ease: [0.65, 0, 0.35, 1] }}
          >
            <ul className="flex flex-col border-t border-line-light">
              {[{ href: "/", label: "Accueil", index: "00" }, ...nav].map((item, i) => (
                <motion.li
                  key={item.href}
                  initial={{ opacity: 0, y: 28 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 + i * 0.06, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                  className="border-b border-line-light"
                >
                  <Link href={item.href} className="flex items-baseline gap-4 py-4">
                    <span className="numeral text-sm opacity-50">{item.index}</span>
                    <span className="font-display text-[2.6rem] leading-none">{item.label}</span>
                  </Link>
                </motion.li>
              ))}
            </ul>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.6 }}
              className="mt-auto grid gap-6 pt-12 text-sm sm:grid-cols-2"
            >
              <div>
                <p className="eyebrow mb-3 opacity-60">Téléphone</p>
                {agency.phones.map((p) => (
                  <a key={p.tel} href={`tel:${p.tel}`} className="block tabular-nums">
                    +216 {p.display}
                  </a>
                ))}
              </div>
              <div>
                <p className="eyebrow mb-3 opacity-60">Agence</p>
                <p>{agency.address.street}</p>
                <p>{agency.address.city}, {agency.address.country}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </ViewTransition>
  );
}
