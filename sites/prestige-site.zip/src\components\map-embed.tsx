import { agency } from "@/lib/agency";
import { cn } from "@/lib/cn";

/** Carte Google Maps de l'agence, désaturée pour s'accorder à la palette. */
export function MapEmbed({ className }: { className?: string }) {
  return (
    <div className={cn("relative overflow-hidden bg-sand", className)}>
      <iframe
        title={`Carte — ${agency.name}, ${agency.address.city}`}
        src={agency.mapsEmbed}
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        className="absolute inset-0 h-full w-full border-0 grayscale-[0.85] sepia-[0.15] contrast-[0.95] transition-[filter] duration-700 hover:grayscale-0 hover:sepia-0"
        allowFullScreen
      />
    </div>
  );
}
