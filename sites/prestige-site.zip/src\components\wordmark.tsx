import { cn } from "@/lib/cn";

/** Logotype typographique : « Prestige » en capitales serif, sous-titre espacé. */
export function Wordmark({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn("inline-flex flex-col items-start leading-none", className)}>
      <span className="font-display text-[1.45rem] tracking-[0.16em] uppercase" style={{ fontWeight: 400 }}>
        Prestige
      </span>
      {!compact && (
        <span className="mt-1 text-[0.5625rem] tracking-[0.42em] uppercase opacity-70">
          Immobilier · Tunisie
        </span>
      )}
    </span>
  );
}
