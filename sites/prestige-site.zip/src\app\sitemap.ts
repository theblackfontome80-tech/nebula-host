import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/agency";
import { properties } from "@/lib/properties";

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ["", "/biens", "/agence", "/contact"].map((path) => ({
    url: `${siteUrl}${path}`,
    changeFrequency: "weekly" as const,
    priority: path === "" ? 1 : 0.8,
  }));
  const biens = properties.map((p) => ({
    url: `${siteUrl}/biens/${p.slug}`,
    lastModified: p.publishedAt,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));
  return [...pages, ...biens];
}
