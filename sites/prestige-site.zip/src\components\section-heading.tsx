import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { LineReveal, Reveal } from "@/components/motion";

/** En-tête de section éditorial : index, rubrique, titre serif. */
export function SectionHeading({
  index,
  label,
  title,
  aside,
  tone = "dark",
  stacked = false,
  className,
}: {
  index: string;
  label: string;
  title: ReactNode[];
  aside?: ReactNode;
  tone?: "dark" | "light";
  stacked?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("grid gap-8", !stacked && "md:grid-cols-12 md:items-end", className)}>
      <div className={stacked ? undefined : "md:col-span-8"}>
        <Reveal
          className={cn(
            "mb-6 flex items-center gap-4 border-t pt-4",
            tone === "dark" ? "border-line" : "border-line-light",
          )}
        >
          <span className="numeral text-sm">{index}</span>
          <span className="eyebrow opacity-70">{label}</span>
        </Reveal>
        <LineReveal
          lines={title}
          className="font-display text-[clamp(2.4rem,5.4vw,5rem)] leading-[0.98]"
        />
      </div>
      {aside && <Reveal delay={0.15} className="md:col-span-4 md:pb-2">{aside}</Reveal>}
    </div>
  );
}
