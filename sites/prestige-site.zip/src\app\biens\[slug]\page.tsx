import type { Metadata } from "next";
import { blurFor } from "@/lib/blur";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ViewTransition } from "react";
import { Gallery } from "@/components/gallery";
import { LineReveal, Reveal } from "@/components/motion";
import { PageTransition } from "@/components/page-transition";
import { PropertyCard } from "@/components/property-card";
import { agency, siteUrl, whatsappLink } from "@/lib/agency";
import {
  getProperty,
  priceLabel,
  properties,
  surfaceLabel,
  transactionLabel,
  zones,
} from "@/lib/properties";

// Toutes les fiches sont prérendues à la compilation (generateStaticParams) :
// la lecture de `params` ne bloque donc jamais réellement la navigation.
export const instant = false;

export function generateStaticParams() {
  return properties.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps<"/biens/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const p = getProperty(slug);
  if (!p) return {};
  const title = `${p.typeLabel} — ${p.district}`;
  return {
    title,
    description: `${transactionLabel(p)} : ${p.title}. ${p.description[0]}`,
    alternates: { canonical: `/biens/${p.slug}` },
    openGraph: { title, images: [{ url: p.images[0].src }] },
  };
}

export default async function PropertyPage({ params }: PageProps<"/biens/[slug]">) {
  const { slug } = await params;
  const p = getProperty(slug);
  if (!p) notFound();

  const zone = zones[p.zone];
  const surface = surfaceLabel(p);
  const others = properties
    .filter((o) => o.slug !== p.slug)
    .sort((a, b) => Number(b.zone === p.zone) - Number(a.zone === p.zone) || Number(b.type === p.type) - Number(a.type === p.type))
    .slice(0, 3);

  const facts: [string, string][] = [
    ["Transaction", transactionLabel(p)],
    ["Prix", priceLabel(p)],
    ["Surface", surface ?? "Sur demande"],
    ...(p.bedrooms ? ([["Chambres", String(p.bedrooms)]] as [string, string][]) : []),
    ...(p.rooms ? ([["Pièces", String(p.rooms)]] as [string, string][]) : []),
    ...(p.floor ? ([["Étage", p.floor]] as [string, string][]) : []),
    ...(p.furnished !== undefined
      ? ([["Ameublement", p.furnished ? "Meublé" : "Non meublé"]] as [string, string][])
      : []),
    ["Secteur", p.district],
  ];

  const whatsappMsg = `Bonjour Prestige Immobilier, je suis intéressé(e) par le bien « ${p.title} » (${p.district}). Pourriez-vous m'en dire plus ?`;
  const mapsSearch = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${p.district.split(",")[0]}, Sousse, Tunisie`)}`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Offer",
    name: p.title,
    url: `${siteUrl}/biens/${p.slug}`,
    description: p.description.join(" "),
    priceCurrency: "TND",
    ...(p.price?.sale ? { price: p.price.sale } : p.price?.rent ? { price: p.price.rent } : {}),
    seller: { "@type": "RealEstateAgent", name: agency.name },
    itemOffered: {
      "@type": p.type === "bureau" ? "Place" : p.type === "villa" ? "SingleFamilyResidence" : "Apartment",
      name: p.typeLabel,
      address: { "@type": "PostalAddress", addressLocality: p.district, addressCountry: "TN" },
      ...(p.bedrooms ? { numberOfBedrooms: p.bedrooms } : {}),
    },
  };

  return (
    <PageTransition>
      <article>
        <header className="mx-auto max-w-[1600px] px-5 pt-32 md:px-10 md:pt-40">
          <Reveal y={10}>
            <nav aria-label="Fil d'Ariane" className="flex items-center gap-3 text-[0.8125rem] text-moss">
              <Link href="/" className="link-underline">Accueil</Link>
              <span aria-hidden>/</span>
              <Link href="/biens" className="link-underline">Biens</Link>
              <span aria-hidden>/</span>
              <span className="truncate text-ink" aria-current="page">{p.title}</span>
            </nav>
          </Reveal>

          <div className="mt-12 grid gap-10 md:mt-16 md:grid-cols-12 md:items-end">
            <div className="md:col-span-8">
              <Reveal className="mb-6 flex flex-wrap items-center gap-x-4 gap-y-2">
                <span className="bg-ink px-2.5 py-1 text-[0.625rem] tracking-[0.18em] text-chalk uppercase">
                  {transactionLabel(p)}
                </span>
                <span className="eyebrow text-moss">{p.typeLabel}</span>
                <span className="eyebrow text-moss">— {zone.name}</span>
              </Reveal>
              <LineReveal
                as="h1"
                immediate
                delay={0.15}
                lines={[p.title]}
                className="font-display text-[clamp(2.6rem,6.4vw,6rem)] leading-[0.96]"
              />
              <Reveal delay={0.3}>
                <p className="font-display mt-5 text-xl text-moss italic md:text-2xl">{p.tagline}</p>
              </Reveal>
            </div>
            <Reveal delay={0.35} className="md:col-span-4 md:text-right">
              <p className="eyebrow text-moss">{p.price ? "Prix" : "Tarif"}</p>
              <p className="font-display mt-2 text-3xl tabular-nums md:text-4xl">{priceLabel(p)}</p>
              {surface && <p className="mt-2 text-sm text-moss">{surface}</p>}
            </Reveal>
          </div>
        </header>

        {/* Image principale — continuité avec la carte cliquée */}
        <div className="mx-auto mt-12 max-w-[1600px] px-5 md:mt-16 md:px-10">
          <ViewTransition name={`bien-${p.slug}`} share="morph" default="none">
            <div className="relative aspect-[4/3] overflow-hidden bg-sand md:aspect-[21/9]">
              <Image
                src={p.images[0].src}
                placeholder={blurFor(p.images[0].src)}
                alt={p.images[0].alt}
                fill
                priority
                sizes="(min-width:1600px) 1520px, 100vw"
                className="object-cover"
              />
            </div>
          </ViewTransition>
        </div>

        {/* Informations essentielles */}
        <section aria-label="Informations essentielles" className="mx-auto max-w-[1600px] px-5 md:px-10">
          <Reveal>
            <dl className="grid grid-cols-2 gap-px border-b border-line bg-line sm:grid-cols-3 lg:grid-flow-col lg:auto-cols-fr lg:grid-cols-none">
              {facts.map(([k, v]) => (
                <div key={k} className="bg-chalk px-4 py-6 lg:first:pl-0">
                  <dt className="eyebrow text-[0.625rem] text-moss">{k}</dt>
                  <dd className="mt-2 text-[0.9375rem]">{v}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </section>

        {/* Description + demande */}
        <div className="mx-auto grid max-w-[1600px] gap-16 px-5 py-20 md:px-10 md:py-28 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <section aria-labelledby="desc">
              <Reveal className="mb-8 flex items-center gap-4 border-t border-line pt-4">
                <span className="numeral text-sm">01</span>
                <h2 id="desc" className="eyebrow opacity-70">Description</h2>
              </Reveal>
              <Reveal>
                <p className="font-display text-[clamp(1.6rem,2.6vw,2.25rem)] leading-[1.2]">{p.description[0]}</p>
              </Reveal>
              <Reveal delay={0.1} className="mt-8 space-y-5 text-[1.0625rem] leading-relaxed text-moss">
                {p.description.slice(1).map((d) => (
                  <p key={d}>{d}</p>
                ))}
              </Reveal>
            </section>

            {p.layout && (
              <section aria-labelledby="agencement" className="mt-20">
                <Reveal className="mb-8 flex items-center gap-4 border-t border-line pt-4">
                  <span className="numeral text-sm">02</span>
                  <h2 id="agencement" className="eyebrow opacity-70">Agencement</h2>
                </Reveal>
                <div className="grid gap-10 sm:grid-cols-2 xl:grid-cols-3">
                  {p.layout.map((g, i) => (
                    <Reveal key={g.title} delay={i * 0.08}>
                      <h3 className="font-display text-2xl italic">{g.title}</h3>
                      <ul className="mt-4 space-y-2 text-[0.9375rem] text-moss">
                        {g.items.map((it) => (
                          <li key={it} className="flex gap-3">
                            <span className="mt-[0.7em] h-px w-3 shrink-0 bg-clay" aria-hidden />
                            {it}
                          </li>
                        ))}
                      </ul>
                    </Reveal>
                  ))}
                </div>
              </section>
            )}

            <section aria-labelledby="prestations" className="mt-20">
              <Reveal className="mb-8 flex items-center gap-4 border-t border-line pt-4">
                <span className="numeral text-sm">{p.layout ? "03" : "02"}</span>
                <h2 id="prestations" className="eyebrow opacity-70">Caractéristiques & équipements</h2>
              </Reveal>
              <ul className="grid border-t border-line sm:grid-cols-2">
                {p.features.map((f, i) => (
                  <Reveal as="li" key={f} delay={(i % 4) * 0.05} className="flex items-baseline gap-4 border-b border-line py-4 sm:odd:pr-6 sm:even:border-l sm:even:pl-6">
                    <span className="numeral w-6 text-xs text-moss">{String(i + 1).padStart(2, "0")}</span>
                    <span className="text-[0.9375rem]">{f}</span>
                  </Reveal>
                ))}
              </ul>
            </section>
          </div>

          {/* Panneau de demande */}
          <aside className="lg:col-span-4 lg:col-start-9" aria-label="Demande d'informations">
            <div className="lg:sticky lg:top-28">
              <Reveal className="bg-paper p-7 md:p-9">
                <p className="eyebrow text-moss">Ce bien vous intéresse ?</p>
                <p className="font-display mt-4 text-3xl leading-tight">Organisons une visite.</p>
                <p className="mt-3 text-[0.9375rem] leading-relaxed text-moss">
                  {agency.visits}. Échangez directement avec l&apos;agence par téléphone ou WhatsApp.
                </p>
                <div className="mt-8 grid gap-3">
                  <a
                    href={whatsappLink(whatsappMsg)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between bg-olive px-6 py-4 text-[0.75rem] tracking-[0.14em] text-chalk uppercase transition-colors hover:bg-ink"
                  >
                    Écrire sur WhatsApp <span aria-hidden>→</span>
                  </a>
                  <Link
                    href={`/contact?bien=${p.slug}`}
                    className="flex items-center justify-between border border-ink/30 px-6 py-4 text-[0.75rem] tracking-[0.14em] uppercase transition-colors hover:border-ink hover:bg-ink hover:text-chalk"
                  >
                    Demander des renseignements <span aria-hidden>→</span>
                  </Link>
                </div>
                <div className="mt-8 border-t border-line pt-6">
                  <p className="eyebrow mb-3 text-[0.625rem] text-moss">Appeler l&apos;agence</p>
                  <ul className="space-y-1">
                    {agency.phones.slice(1).map((ph) => (
                      <li key={ph.tel}>
                        <a href={`tel:${ph.tel}`} className="font-display text-2xl tabular-nums link-underline">
                          {ph.display}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
              <a
                href={p.source}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 inline-block text-[0.8125rem] text-moss link-underline"
              >
                Voir l&apos;annonce sur Instagram ↗
              </a>
            </div>
          </aside>
        </div>

        {/* Galerie */}
        {p.images.length > 1 && (
          <section aria-labelledby="galerie" className="mx-auto max-w-[1600px] px-5 pb-20 md:px-10 md:pb-28">
            <Reveal className="mb-10 flex items-center justify-between border-t border-line pt-4">
              <h2 id="galerie" className="eyebrow opacity-70">Galerie</h2>
              <p className="text-[0.75rem] text-moss">Photographies d&apos;ambiance — visuels du bien sur demande</p>
            </Reveal>
            <Gallery images={p.images.slice(1)} title={p.title} />
          </section>
        )}

        {/* Localisation */}
        <section aria-labelledby="localisation" className="grain relative bg-olive text-chalk">
          <div className="relative mx-auto grid max-w-[1600px] gap-12 px-5 py-20 md:grid-cols-12 md:px-10 md:py-28">
            <div className="md:col-span-5">
              <Reveal className="mb-8 flex items-center gap-4 border-t border-line-light pt-4">
                <span className="numeral text-sm">—</span>
                <h2 id="localisation" className="eyebrow opacity-70">Localisation</h2>
              </Reveal>
              <LineReveal
                lines={[zone.name]}
                as="p"
                className="font-display text-[clamp(2.5rem,5vw,4.5rem)] leading-none"
              />
              <p className="mt-3 text-chalk/70">{p.district}</p>
            </div>
            <Reveal delay={0.1} className="md:col-span-6 md:col-start-7">
              <p className="text-[1.0625rem] leading-relaxed text-chalk/80">{zone.description}</p>
              <p className="mt-5 text-[0.9375rem] leading-relaxed text-chalk/60">
                L&apos;adresse exacte est communiquée lors de la prise de rendez-vous.
              </p>
              <div className="mt-8 flex flex-wrap gap-6">
                <a href={mapsSearch} target="_blank" rel="noopener noreferrer" className="text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                  Voir le secteur sur Google Maps ↗
                </a>
                <Link href={`/biens?zone=${p.zone}`} className="text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                  Autres biens — {zone.name}
                </Link>
              </div>
            </Reveal>
          </div>
        </section>

        {/* Autres biens */}
        <section aria-labelledby="autres" className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-32">
          <Reveal className="mb-12 flex items-end justify-between gap-6 border-t border-line pt-4">
            <h2 id="autres" className="font-display text-[clamp(2rem,4vw,3.25rem)] leading-none">
              À découvrir <em className="italic">également</em>
            </h2>
            <Link href="/biens" className="shrink-0 text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
              Tous les biens
            </Link>
          </Reveal>
          <div className="grid gap-x-8 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
            {others.map((o, i) => (
              <Reveal key={o.slug} delay={i * 0.08}>
                <PropertyCard property={o} index={properties.indexOf(o) + 1} />
              </Reveal>
            ))}
          </div>
        </section>
      </article>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </PageTransition>
  );
}
