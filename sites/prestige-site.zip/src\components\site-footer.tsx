import Link from "next/link";
import { agency, whatsappLink } from "@/lib/agency";
import { zones } from "@/lib/properties";

export function SiteFooter() {
  return (
    <footer className="grain relative overflow-hidden bg-olive text-chalk">
      <div className="mx-auto max-w-[1600px] px-5 pt-20 pb-8 md:px-10 md:pt-28">
        <div className="grid gap-12 border-b border-line-light pb-16 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="font-display max-w-sm text-3xl leading-tight md:text-4xl">
              Achetez, vendez, louez <em className="italic">avec sérénité.</em>
            </p>
            <a
              href={agency.instagram.url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-block text-sm link-underline pb-0.5"
            >
              Instagram — {agency.instagram.handle}
            </a>
          </div>

          <nav aria-label="Pied de page" className="grid grid-cols-2 gap-10 sm:grid-cols-3 md:col-span-7">
            <div>
              <p className="eyebrow mb-5 opacity-50">Navigation</p>
              <ul className="space-y-2.5 text-[0.9375rem]">
                <li><Link className="link-underline" href="/">Accueil</Link></li>
                <li><Link className="link-underline" href="/biens">Tous les biens</Link></li>
                <li><Link className="link-underline" href="/agence">L&apos;agence</Link></li>
                <li><Link className="link-underline" href="/contact">Contact</Link></li>
              </ul>
            </div>
            <div>
              <p className="eyebrow mb-5 opacity-50">Secteurs</p>
              <ul className="space-y-2.5 text-[0.9375rem]">
                {Object.entries(zones).map(([id, z]) => (
                  <li key={id}>
                    <Link className="link-underline" href={`/biens?zone=${id}`}>{z.name}</Link>
                  </li>
                ))}
              </ul>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <p className="eyebrow mb-5 opacity-50">Contact</p>
              <ul className="space-y-2.5 text-[0.9375rem] tabular-nums">
                {agency.phones.map((p) => (
                  <li key={p.tel}>
                    <a className="link-underline" href={`tel:${p.tel}`}>+216 {p.display}</a>
                  </li>
                ))}
                <li>
                  <a className="link-underline" href={whatsappLink()} target="_blank" rel="noopener noreferrer">
                    WhatsApp
                  </a>
                </li>
                <li>
                  <a className="link-underline" href={agency.mapsUrl} target="_blank" rel="noopener noreferrer">
                    Itinéraire
                  </a>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        <p
          aria-hidden
          className="font-display pointer-events-none mt-10 text-center text-[clamp(4rem,19vw,19rem)] leading-[0.8] tracking-[0.04em] uppercase opacity-95 select-none"
          style={{ fontWeight: 300 }}
        >
          Prestige
        </p>

        <div className="mt-10 flex flex-col gap-3 text-[0.75rem] text-chalk/60 md:flex-row md:items-center md:justify-between">
          <p>© {agency.name} — {agency.address.street}, {agency.address.city}</p>
          <p className="numeral">{agency.coordinatesLabel}</p>
        </div>
      </div>
    </footer>
  );
}
