/**
 * Coordonnées de l'agence.
 * Sources vérifiées (novembre 2026) :
 *  - Fiche Google Maps « Agence Prestige Immobilier » (Hammam Sousse, 50 250 288)
 *  - Bio Instagram @agence_prestige_immobilier (« Vente Location Estimation »,
 *    « Contact : 50 250 288 / 52 347 097 », « Boulevard 14 janvier, route touristique »)
 *  - Annonces Instagram (52 347 097 / 58 347 097)
 */
export const agency = {
  name: "Agence Prestige Immobilier",
  shortName: "Prestige Immobilier",
  instagramName: "Prestige Immobilier Tunisie",
  baseline: "L'immobilier en toute confiance.",
  services: ["Vente", "Location", "Estimation"],
  address: {
    street: "Boulevard du 14 Janvier, Route Touristique",
    city: "Hammam Sousse",
    country: "Tunisie",
    plusCode: "VHMX+87W",
  },
  geo: { lat: 35.8833574, lng: 10.5981893 },
  coordinatesLabel: "35°53′00″ N — 10°35′53″ E",
  phones: [
    { display: "50 250 288", tel: "+21650250288" },
    { display: "52 347 097", tel: "+21652347097" },
    { display: "58 347 097", tel: "+21658347097" },
  ],
  whatsapp: "21652347097",
  instagram: {
    handle: "@agence_prestige_immobilier",
    url: "https://www.instagram.com/agence_prestige_immobilier/",
  },
  mapsUrl: "https://maps.app.goo.gl/YUhRzWQ2Q1p4s4t4A",
  mapsEmbed:
    "https://www.google.com/maps?q=35.8833574,10.5981893&z=16&hl=fr&output=embed",
  visits: "Visites sur rendez-vous",
} as const;

/** Domaine de production : à définir via NEXT_PUBLIC_SITE_URL lors du déploiement. */
export const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ?? "http://localhost:3000";

export function whatsappLink(message?: string) {
  const base = `https://wa.me/${agency.whatsapp}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}
