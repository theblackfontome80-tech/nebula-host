"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { cn } from "@/lib/cn";
import { properties, typeLabels, zones, type Transaction } from "@/lib/properties";

/** Recherche de la page d'accueil : envoie vers /biens avec les filtres dans l'URL. */
export function PropertySearch({ className }: { className?: string }) {
  const router = useRouter();
  const [transaction, setTransaction] = useState<Transaction>("vente");
  const [type, setType] = useState("");
  const [zone, setZone] = useState("");

  const count = properties.filter(
    (p) =>
      p.transactions.includes(transaction) &&
      (!type || p.type === type) &&
      (!zone || p.zone === zone),
  ).length;

  function submit(e: FormEvent) {
    e.preventDefault();
    const q = new URLSearchParams({ transaction });
    if (type) q.set("type", type);
    if (zone) q.set("zone", zone);
    router.push(`/biens?${q.toString()}`);
  }

  return (
    <form
      onSubmit={submit}
      role="search"
      aria-label="Rechercher un bien"
      className={cn("grid bg-chalk text-ink md:grid-cols-[auto_1fr_1fr_auto]", className)}
    >
      <fieldset className="flex border-b border-line md:border-r md:border-b-0">
        <legend className="sr-only">Type de transaction</legend>
        {(["vente", "location"] as const).map((t) => (
          <label
            key={t}
            className={cn(
              "relative flex flex-1 cursor-pointer items-center justify-center px-6 py-5 text-[0.8125rem] tracking-wide transition-colors md:flex-none md:px-7",
              transaction === t ? "text-ink" : "text-moss hover:text-ink",
            )}
          >
            <input
              type="radio"
              name="transaction"
              value={t}
              checked={transaction === t}
              onChange={() => setTransaction(t)}
              className="peer sr-only"
            />
            <span className="peer-focus-visible:outline peer-focus-visible:outline-1 peer-focus-visible:outline-offset-4 peer-focus-visible:outline-clay">
              {t === "vente" ? "Acheter" : "Louer"}
            </span>
            <span
              className={cn(
                "absolute bottom-0 left-6 right-6 h-px bg-ink transition-transform duration-500 ease-[var(--ease-out-soft)] md:left-7 md:right-7",
                transaction === t ? "scale-x-100" : "scale-x-0",
              )}
            />
          </label>
        ))}
      </fieldset>

      <Field label="Type de bien" id="search-type">
        <select id="search-type" value={type} onChange={(e) => setType(e.target.value)} className={selectClass}>
          <option value="">Tous les biens</option>
          {Object.entries(typeLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </Field>

      <Field label="Secteur" id="search-zone" className="md:border-l md:border-line">
        <select id="search-zone" value={zone} onChange={(e) => setZone(e.target.value)} className={selectClass}>
          <option value="">Tout le littoral</option>
          {Object.entries(zones).map(([k, z]) => (
            <option key={k} value={k}>
              {z.name}
            </option>
          ))}
        </select>
      </Field>

      <button
        type="submit"
        className="group flex items-center justify-between gap-6 bg-olive px-7 py-5 text-chalk transition-colors duration-300 hover:bg-ink md:justify-center"
      >
        <span className="text-[0.75rem] tracking-[0.16em] uppercase">
          Voir {count} bien{count > 1 ? "s" : ""}
        </span>
        <svg width="22" height="10" viewBox="0 0 22 10" fill="none" aria-hidden className="transition-transform duration-500 group-hover:translate-x-1">
          <path d="M0 5h20m0 0-4-4m4 4-4 4" stroke="currentColor" strokeWidth="1" />
        </svg>
      </button>
    </form>
  );
}

const selectClass =
  "w-full appearance-none bg-transparent pr-8 text-[0.9375rem] outline-none cursor-pointer";

function Field({
  label,
  id,
  children,
  className,
}: {
  label: string;
  id: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("relative border-b border-line px-6 py-3.5 md:border-b-0 md:px-7", className)}>
      <label htmlFor={id} className="eyebrow block text-[0.625rem] text-moss">
        {label}
      </label>
      <div className="relative mt-1">
        {children}
        <svg
          className="pointer-events-none absolute top-1/2 right-0 -translate-y-1/2"
          width="10"
          height="6"
          viewBox="0 0 10 6"
          fill="none"
          aria-hidden
        >
          <path d="m1 1 4 4 4-4" stroke="currentColor" strokeWidth="1" />
        </svg>
      </div>
    </div>
  );
}
