import type { Metadata } from "next";
import Link from "next/link";
import { ContactBand } from "@/components/contact-band";
import { MapEmbed } from "@/components/map-embed";
import { LineReveal, Reveal, RevealImage } from "@/components/motion";
import { PageTransition } from "@/components/page-transition";
import { agency } from "@/lib/agency";
import { properties, zones } from "@/lib/properties";

export const metadata: Metadata = {
  title: "L'agence",
  description:
    "Prestige Immobilier Tunisie, agence immobilière à Hammam Sousse : vente, location et estimation, pour particuliers et professionnels.",
  alternates: { canonical: "/agence" },
};

const principles = [
  {
    title: "Écouter",
    text: "Chaque projet commence par une conversation : votre budget, vos contraintes, la manière dont vous souhaitez vivre ou travailler.",
  },
  {
    title: "Sélectionner",
    text: "Nous présentons des biens que nous connaissons, décrits avec précision, pour que chaque visite ait du sens.",
  },
  {
    title: "Accompagner",
    text: "Visites sur rendez-vous, échanges directs, suivi jusqu'à la signature : un accompagnement personnalisé, du début à la fin.",
  },
];

export default function AgencePage() {
  return (
    <PageTransition>
      {/* Ouverture */}
      <section className="mx-auto max-w-[1600px] px-5 pt-36 md:px-10 md:pt-48">
        <Reveal className="mb-6 flex items-center gap-4">
          <span className="numeral text-sm">02</span>
          <span className="eyebrow opacity-70">L&apos;agence</span>
        </Reveal>
        <LineReveal
          as="h1"
          immediate
          delay={0.2}
          lines={["Votre partenaire", <em key="e" className="italic">de confiance,</em>, "à Hammam Sousse."]}
          className="font-display text-[clamp(2.8rem,8vw,7.5rem)] leading-[0.94]"
        />
        <div className="mt-14 grid gap-10 md:mt-20 md:grid-cols-12">
          <Reveal delay={0.4} className="md:col-span-5 md:col-start-8">
            <p className="text-[1.125rem] leading-relaxed text-moss">
              {agency.instagramName} accompagne celles et ceux qui achètent, vendent ou louent sur
              le littoral de Sousse. Villas, appartements, bureaux : un même souci de clarté et de
              confiance, à chaque étape.
            </p>
          </Reveal>
        </div>
      </section>

      <div className="mx-auto mt-16 max-w-[1600px] px-5 md:mt-24 md:px-10">
        <RevealImage
          src="/images/coast.webp"
          alt="Palmiers et lumière du soir sur le littoral"
          sizes="100vw"
          priority
          className="aspect-[4/3] md:aspect-[21/9]"
          parallax={8}
        />
      </div>

      {/* Repères (données réelles du site) */}
      <section aria-label="Repères" className="mx-auto max-w-[1600px] px-5 md:px-10">
        <dl className="grid grid-cols-1 border-b border-line sm:grid-cols-3">
          {[
            [String(agency.services.length), "métiers", agency.services.join(" · ")],
            [String(Object.keys(zones).length), "secteurs", Object.values(zones).map((z) => z.name).join(" · ")],
            [String(properties.length), "biens proposés", "À la vente et à la location"],
          ].map(([n, label, detail], i) => (
            <Reveal key={label} delay={i * 0.08} className="border-line py-10 sm:border-l sm:px-8 sm:first:border-l-0 sm:first:pl-0 max-sm:border-t max-sm:first:border-t-0">
              <dt className="sr-only">{label}</dt>
              <dd>
                <span className="font-display text-[clamp(3.5rem,6vw,5.5rem)] leading-none">{n}</span>
                <span className="font-display ml-3 text-2xl italic">{label}</span>
                <span className="mt-3 block text-[0.875rem] text-moss">{detail}</span>
              </dd>
            </Reveal>
          ))}
        </dl>
      </section>

      {/* Approche */}
      <section aria-labelledby="approche" className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-40">
        <div className="grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-32">
              <Reveal className="mb-6 flex items-center gap-4 border-t border-line pt-4">
                <span className="numeral text-sm">—</span>
                <h2 id="approche" className="eyebrow opacity-70">Notre approche</h2>
              </Reveal>
              <LineReveal
                as="p"
                lines={["Trois gestes,", <em key="e" className="italic">une méthode.</em>]}
                className="font-display text-[clamp(2.2rem,4vw,3.75rem)] leading-[1]"
              />
            </div>
          </div>
          <ol className="lg:col-span-7 lg:col-start-6">
            {principles.map((p, i) => (
              <Reveal as="li" key={p.title} className="grid gap-4 border-t border-line py-10 sm:grid-cols-[5rem_1fr] md:py-14">
                <span className="numeral text-[2.5rem] leading-none text-clay">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <h3 className="font-display text-[2rem] leading-none md:text-[2.5rem]">{p.title}</h3>
                  <p className="mt-4 max-w-lg text-[1.0625rem] leading-relaxed text-moss">{p.text}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* Citation */}
      <section aria-label="Notre engagement" className="bg-sand/60">
        <div className="mx-auto grid max-w-[1600px] gap-12 px-5 py-24 md:grid-cols-12 md:px-10 md:py-36">
          <div className="md:col-span-4">
            <RevealImage src="/images/villa-3.webp" alt="Salon lumineux aux matières naturelles" sizes="(min-width:768px) 33vw, 100vw" className="aspect-[3/4]" parallax={5} />
          </div>
          <div className="flex flex-col justify-center md:col-span-7 md:col-start-6">
            <LineReveal
              as="p"
              lines={["« Donnez vie", "à vos projets immobiliers", <em key="e" className="italic">avec nous. »</em>]}
              className="font-display text-[clamp(2.2rem,5vw,4.75rem)] leading-[1.02]"
            />
            <Reveal delay={0.3} className="mt-10 flex items-center gap-4">
              <span className="h-px w-10 bg-clay" />
              <span className="eyebrow text-moss">{agency.name}</span>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Nous rendre visite */}
      <section aria-labelledby="visite" className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-36">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Reveal className="mb-6 flex items-center gap-4 border-t border-line pt-4">
              <span className="numeral text-sm">—</span>
              <h2 id="visite" className="eyebrow opacity-70">Nous rendre visite</h2>
            </Reveal>
            <Reveal>
              <address className="font-display text-3xl leading-tight not-italic md:text-4xl">
                {agency.address.street},
                <br />
                <em className="italic">{agency.address.city}</em>
              </address>
              <p className="mt-6 text-[0.9375rem] text-moss">
                {agency.visits}. Code Google : {agency.address.plusCode}.
              </p>
              <div className="mt-8 flex flex-wrap gap-6">
                <a href={agency.mapsUrl} target="_blank" rel="noopener noreferrer" className="text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                  Itinéraire ↗
                </a>
                <Link href="/contact" className="text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                  Prendre rendez-vous
                </Link>
              </div>
            </Reveal>
          </div>
          <Reveal delay={0.1} className="lg:col-span-8">
            <MapEmbed className="aspect-[4/3] md:aspect-[16/9]" />
          </Reveal>
        </div>
      </section>

      <ContactBand />
    </PageTransition>
  );
}
