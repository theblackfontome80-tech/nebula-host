"use client";

import Image from "next/image";
import { blurFor } from "@/lib/blur";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/cn";

export const services = [
  {
    title: "Vente",
    text: "Mise en valeur de votre bien, sélection d'acquéreurs sérieux, visites sur rendez-vous et accompagnement jusqu'à la signature.",
    image: "/images/villa-6.webp",
    alt: "Piscine et terrasse d'une villa",
    href: "/biens?transaction=vente",
    cta: "Biens à vendre",
  },
  {
    title: "Location",
    text: "Locations annuelles, meublées ou non : nous présentons votre logement aux bons locataires et organisons chaque visite.",
    image: "/images/soviva-1.webp",
    alt: "Salon lumineux d'un appartement meublé",
    href: "/biens?transaction=location",
    cta: "Biens à louer",
  },
  {
    title: "Estimation",
    text: "Une estimation fondée sur notre connaissance du terrain, de Kantaoui à Chott Mariem, pour vendre ou louer au juste prix.",
    image: "/images/white.webp",
    alt: "Architecture méditerranéenne blanche",
    href: "/contact?objet=estimation",
    cta: "Demander une estimation",
  },
  {
    title: "Immobilier professionnel",
    text: "Bureaux et plateaux à la vente ou à la location, pour cabinets, sièges d'entreprise et activités de service.",
    image: "/images/bureau-1.webp",
    alt: "Plateau de bureaux lumineux",
    href: "/biens?type=bureau",
    cta: "Bureaux disponibles",
  },
  {
    title: "Accompagnement personnalisé",
    text: "Un interlocuteur unique, joignable par téléphone, WhatsApp ou message, du premier échange à la remise des clés.",
    image: "/images/interior.webp",
    alt: "Espace de réception",
    href: "/contact",
    cta: "Nous contacter",
  },
];

/**
 * Liste des expertises : la photo du service survolé (ou focalisé) s'affiche
 * dans un panneau fixe à droite, sans jamais recouvrir le texte.
 */
export function ServicesList() {
  const [active, setActive] = useState(0);
  const [hovering, setHovering] = useState(false);

  return (
    <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
      <ul
        className="border-t border-line lg:col-span-7"
        onMouseEnter={() => setHovering(true)}
        onMouseLeave={() => setHovering(false)}
      >
        {services.map((s, i) => {
          const isActive = active === i;
          return (
            <li key={s.title} className="border-b border-line" onMouseEnter={() => setActive(i)}>
              <Link
                href={s.href}
                onFocus={() => setActive(i)}
                className={cn(
                  "group grid grid-cols-[2.5rem_1fr_auto] items-start gap-x-4 py-8 transition-opacity duration-500 md:grid-cols-[3.5rem_1fr_auto] md:py-10",
                  hovering && !isActive ? "lg:opacity-40" : "opacity-100",
                )}
              >
                <span className="numeral pt-[0.55em] text-sm text-moss">{String(i + 1).padStart(2, "0")}</span>
                <span className="min-w-0">
                  <span className="font-display block text-[clamp(1.9rem,3.4vw,3rem)] leading-[1.05] transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:translate-x-2">
                    {s.title}
                  </span>
                  <span className="mt-3 block max-w-lg text-[0.9375rem] leading-relaxed text-moss">{s.text}</span>
                  <span className="mt-4 inline-block text-[0.6875rem] tracking-[0.16em] uppercase link-underline pb-0.5 lg:hidden">
                    {s.cta}
                  </span>
                </span>
                <svg
                  width="22"
                  height="10"
                  viewBox="0 0 22 10"
                  fill="none"
                  aria-hidden
                  className="mt-[1.1em] transition-transform duration-500 group-hover:translate-x-1"
                >
                  <path d="M0 5h20m0 0-4-4m4 4-4 4" stroke="currentColor" strokeWidth="1" />
                </svg>
              </Link>
            </li>
          );
        })}
      </ul>

      {/* Panneau photo (grand écran) */}
      <div className="hidden lg:col-span-5 lg:block">
        <div className="sticky top-28">
          <div className="relative aspect-[4/5] overflow-hidden bg-sand">
            <AnimatePresence initial={false}>
              <motion.div
                key={active}
                className="absolute inset-0"
                initial={{ clipPath: "inset(100% 0 0 0)" }}
                animate={{ clipPath: "inset(0% 0 0 0)" }}
                exit={{ opacity: 0.7 }}
                transition={{ duration: 0.8, ease: [0.65, 0, 0.35, 1] }}
              >
                <motion.div
                  className="absolute inset-0"
                  initial={{ scale: 1.12 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
                >
                  <Image
                    src={services[active].image}
                    placeholder={blurFor(services[active].image)}
                    alt={services[active].alt}
                    fill
                    sizes="(min-width:1024px) 38vw, 0px"
                    className="object-cover"
                  />
                </motion.div>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="mt-4 flex items-baseline justify-between gap-4">
            <AnimatePresence mode="wait" initial={false}>
              <motion.p
                key={active}
                className="font-display text-xl italic"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.35 }}
              >
                {services[active].title}
              </motion.p>
            </AnimatePresence>
            <Link
              href={services[active].href}
              className="shrink-0 text-[0.6875rem] tracking-[0.16em] uppercase link-underline pb-0.5"
            >
              {services[active].cta}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
