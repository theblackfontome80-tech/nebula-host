import type { Metadata } from "next";
import { Suspense } from "react";
import { ContactBand } from "@/components/contact-band";
import { ListingExplorer } from "@/components/listing-explorer";
import { LineReveal, Reveal } from "@/components/motion";
import { PageTransition } from "@/components/page-transition";
import { properties } from "@/lib/properties";

export const metadata: Metadata = {
  title: "Biens à vendre et à louer",
  description:
    "Villas, appartements et bureaux à vendre et à louer à Port El Kantaoui, Hammam Sousse, Sousse et Chott Mariem — Prestige Immobilier.",
  alternates: { canonical: "/biens" },
};

export default function BiensPage() {
  return (
    <PageTransition>
      <section className="mx-auto max-w-[1600px] px-5 pt-36 pb-24 md:px-10 md:pt-48 md:pb-36">
        <div className="grid gap-10 md:grid-cols-12 md:items-end">
          <div className="md:col-span-8">
            <Reveal className="mb-6 flex items-center gap-4">
              <span className="numeral text-sm">01</span>
              <span className="eyebrow opacity-70">Les biens</span>
            </Reveal>
            <LineReveal
              as="h1"
              immediate
              delay={0.2}
              lines={["Trouver le lieu", <em key="e" className="italic">qui vous ressemble.</em>]}
              className="font-display text-[clamp(2.8rem,7vw,6.5rem)] leading-[0.95]"
            />
          </div>
          <Reveal delay={0.4} className="md:col-span-4">
            <p className="max-w-sm text-[0.9375rem] leading-relaxed text-moss md:ml-auto">
              {properties.length} biens actuellement proposés par l&apos;agence, à la vente et à la
              location. Chaque fiche reprend l&apos;annonce publiée par l&apos;agence.
            </p>
          </Reveal>
        </div>

        <div className="mt-16 md:mt-24">
          <Suspense fallback={<div className="h-[60vh]" />}>
            <ListingExplorer />
          </Suspense>
        </div>

        <p className="mt-24 max-w-xl text-[0.75rem] leading-relaxed text-moss">
          Photographies d&apos;ambiance non contractuelles. Les visuels réels de chaque bien sont
          disponibles sur demande et lors des visites, organisées sur rendez-vous.
        </p>
      </section>
      <ContactBand />
    </PageTransition>
  );
}
