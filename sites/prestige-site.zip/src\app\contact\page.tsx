import type { Metadata } from "next";
import { Suspense } from "react";
import { ContactForm } from "@/components/contact-form";
import { MapEmbed } from "@/components/map-embed";
import { LineReveal, Reveal } from "@/components/motion";
import { PageTransition } from "@/components/page-transition";
import { agency, whatsappLink } from "@/lib/agency";

export const metadata: Metadata = {
  title: "Contact",
  description: `Contactez ${agency.name} à Hammam Sousse : ${agency.phones.map((p) => p.display).join(", ")}. Visites sur rendez-vous.`,
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <PageTransition>
      <section className="mx-auto max-w-[1600px] px-5 pt-36 pb-20 md:px-10 md:pt-48 md:pb-28">
        <Reveal className="mb-6 flex items-center gap-4">
          <span className="numeral text-sm">04</span>
          <span className="eyebrow opacity-70">Contact</span>
        </Reveal>
        <LineReveal
          as="h1"
          immediate
          delay={0.2}
          lines={["Une question,", <em key="e" className="italic">un projet, une visite.</em>]}
          className="font-display text-[clamp(2.8rem,7.5vw,7rem)] leading-[0.95]"
        />

        <div className="mt-20 grid gap-16 lg:mt-28 lg:grid-cols-12">
          {/* Coordonnées */}
          <Reveal delay={0.3} className="lg:col-span-4">
            <dl className="divide-y divide-line border-y border-line">
              <div className="py-7">
                <dt className="eyebrow mb-3 text-moss">Téléphone</dt>
                <dd className="space-y-1">
                  {agency.phones.map((p) => (
                    <a key={p.tel} href={`tel:${p.tel}`} className="font-display block text-3xl tabular-nums link-underline w-fit">
                      +216 {p.display}
                    </a>
                  ))}
                </dd>
              </div>
              <div className="py-7">
                <dt className="eyebrow mb-3 text-moss">Messagerie</dt>
                <dd className="flex flex-col gap-2 text-[1.0625rem]">
                  <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="link-underline w-fit">
                    WhatsApp — {agency.phones[1].display} ↗
                  </a>
                  <a href={agency.instagram.url} target="_blank" rel="noopener noreferrer" className="link-underline w-fit">
                    Instagram — {agency.instagram.handle} ↗
                  </a>
                </dd>
              </div>
              <div className="py-7">
                <dt className="eyebrow mb-3 text-moss">Adresse</dt>
                <dd>
                  <address className="text-[1.0625rem] leading-relaxed not-italic">
                    {agency.address.street}
                    <br />
                    {agency.address.city}, {agency.address.country}
                  </address>
                  <a href={agency.mapsUrl} target="_blank" rel="noopener noreferrer" className="mt-3 inline-block text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                    Ouvrir dans Google Maps ↗
                  </a>
                </dd>
              </div>
              <div className="py-7">
                <dt className="eyebrow mb-3 text-moss">Visites</dt>
                <dd className="text-[1.0625rem]">{agency.visits}</dd>
              </div>
            </dl>
          </Reveal>

          {/* Formulaire */}
          <Reveal delay={0.4} className="lg:col-span-7 lg:col-start-6">
            <Suspense fallback={<div className="h-[480px]" />}>
              <ContactForm />
            </Suspense>
          </Reveal>
        </div>
      </section>

      <section aria-label="Plan d'accès" className="mx-auto max-w-[1600px] px-5 pb-24 md:px-10 md:pb-36">
        <Reveal>
          <MapEmbed className="aspect-[4/5] sm:aspect-[16/9] lg:aspect-[21/8]" />
        </Reveal>
        <div className="mt-4 flex flex-wrap justify-between gap-2 text-[0.75rem] text-moss">
          <span>{agency.name} — {agency.address.city}</span>
          <span className="numeral">{agency.coordinatesLabel}</span>
        </div>
      </section>
    </PageTransition>
  );
}
