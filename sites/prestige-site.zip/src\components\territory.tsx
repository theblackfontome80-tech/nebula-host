"use client";

import Image from "next/image";
import { blurFor } from "@/lib/blur";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/cn";
import { properties, zones, type ZoneId } from "@/lib/properties";

const zoneImages: Record<ZoneId, string> = {
  "port-el-kantaoui": "/images/villa-1.webp",
  "hammam-sousse": "/images/coast.webp",
  sousse: "/images/panorama-1.webp",
  "chott-mariem": "/images/chott-1.webp",
};

/** Ordre géographique, du sud au nord le long de la côte. */
const order: ZoneId[] = ["sousse", "hammam-sousse", "port-el-kantaoui", "chott-mariem"];

export function Territory() {
  const [active, setActive] = useState<ZoneId>("hammam-sousse");
  const zone = zones[active];
  const count = properties.filter((p) => p.zone === active).length;

  return (
    <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
      <div className="relative aspect-[4/5] overflow-hidden bg-moss lg:col-span-6 lg:aspect-auto lg:min-h-[640px]">
        <AnimatePresence initial={false}>
          <motion.div
            key={active}
            className="absolute inset-0"
            initial={{ clipPath: "inset(0 0 0 100%)" }}
            animate={{ clipPath: "inset(0 0 0 0%)" }}
            exit={{ opacity: 0.6 }}
            transition={{ duration: 0.9, ease: [0.65, 0, 0.35, 1] }}
          >
            <motion.div
              className="absolute inset-0"
              initial={{ scale: 1.15 }}
              animate={{ scale: 1 }}
              transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
            >
              <Image src={zoneImages[active]} placeholder={blurFor(zoneImages[active])} alt="" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" />
            </motion.div>
          </motion.div>
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" />
        <div className="absolute right-0 bottom-0 left-0 p-6 md:p-8">
          <p className="eyebrow text-chalk/70">{zone.short}</p>
          <p className="font-display mt-2 text-4xl md:text-5xl">{zone.name}</p>
        </div>
      </div>

      <div className="flex flex-col lg:col-span-6">
        <ul className="border-t border-line-light" role="tablist" aria-label="Secteurs">
          {order.map((id, i) => {
            const z = zones[id];
            const n = properties.filter((p) => p.zone === id).length;
            const isActive = id === active;
            return (
              <li key={id} className="border-b border-line-light" role="presentation">
                <button
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  aria-controls="secteur-detail"
                  onMouseEnter={() => setActive(id)}
                  onFocus={() => setActive(id)}
                  onClick={() => setActive(id)}
                  className="group flex w-full items-baseline gap-5 py-5 text-left md:py-6"
                >
                  <span className="numeral w-6 text-sm opacity-50">{String(i + 1).padStart(2, "0")}</span>
                  <span
                    className={cn(
                      "font-display flex-1 text-[clamp(1.75rem,3.2vw,2.75rem)] leading-none transition-all duration-500",
                      isActive ? "italic opacity-100" : "opacity-45 group-hover:opacity-80",
                    )}
                  >
                    {z.name}
                  </span>
                  <span className="text-[0.75rem] tabular-nums opacity-60">
                    {n} bien{n > 1 ? "s" : ""}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>

        <div id="secteur-detail" role="tabpanel" className="mt-10 min-h-[9rem] lg:mt-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <p className="max-w-lg text-[1.0625rem] leading-relaxed text-chalk/80">{zone.description}</p>
              <Link
                href={`/biens?zone=${active}`}
                className="mt-6 inline-flex items-center gap-3 text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1"
              >
                {count > 0 ? `Voir les ${count} bien${count > 1 ? "s" : ""} — ${zone.name}` : `Biens à ${zone.name}`}
              </Link>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
