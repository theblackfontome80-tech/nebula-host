import Image from "next/image";
import { blurFor } from "@/lib/blur";
import Link from "next/link";
import { ViewTransition } from "react";
import { cn } from "@/lib/cn";
import {
  compactPrice,
  mainSurface,
  priceLabel,
  transactionLabel,
  zones,
  type Property,
} from "@/lib/properties";

export function PropertyCard({
  property: p,
  index,
  aspect = "aspect-[4/5]",
  sizes = "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw",
  priority = false,
  className,
}: {
  property: Property;
  index?: number;
  aspect?: string;
  sizes?: string;
  priority?: boolean;
  className?: string;
}) {
  const surface = mainSurface(p);
  return (
    <article className={cn("group relative", className)}>
      <Link
        href={`/biens/${p.slug}`}
        className="block focus-visible:outline-offset-8"
        aria-label={`${p.title} — ${p.district}, ${priceLabel(p)}`}
      >
        <div className={cn("relative overflow-hidden bg-sand", aspect)}>
          <ViewTransition name={`bien-${p.slug}`} share="morph" default="none">
            <div className="absolute inset-0">
              <Image
                src={p.images[0].src}
                placeholder={blurFor(p.images[0].src)}
                alt={p.images[0].alt}
                fill
                sizes={sizes}
                priority={priority}
                className="object-cover transition-transform duration-[1.6s] ease-[var(--ease-out-soft)] group-hover:scale-[1.045]"
              />
            </div>
          </ViewTransition>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/45 via-transparent to-transparent opacity-80" />
          <div className="absolute top-0 left-0 flex w-full items-start justify-between p-4 text-chalk md:p-5">
            <span className="bg-chalk px-2.5 py-1 text-[0.625rem] tracking-[0.18em] text-ink uppercase">
              {transactionLabel(p)}
            </span>
            {index !== undefined && (
              <span className="numeral text-sm">N° {String(index).padStart(2, "0")}</span>
            )}
          </div>
          <div className="absolute right-0 bottom-0 left-0 flex items-end justify-between p-4 text-chalk md:p-5">
            <span className="eyebrow">{zones[p.zone].name}</span>
            <span className="flex translate-y-2 items-center gap-2 text-[0.75rem] tracking-wide opacity-0 transition-all duration-500 ease-[var(--ease-out-soft)] group-hover:translate-y-0 group-hover:opacity-100">
              Découvrir
              <svg width="18" height="10" viewBox="0 0 18 10" fill="none" aria-hidden>
                <path d="M0 5h16m0 0L12 1m4 4-4 4" stroke="currentColor" strokeWidth="1" />
              </svg>
            </span>
          </div>
        </div>

        <div className="pt-5">
          <div className="flex items-baseline justify-between gap-4">
            <p className="eyebrow text-moss">{p.typeLabel}</p>
            <p className="text-[0.8125rem] text-moss">{p.district.split(",")[0]}</p>
          </div>
          <h3 className="font-display mt-2 text-[1.65rem] leading-[1.08] md:text-[1.85rem]">
            <span className="bg-[linear-gradient(currentColor,currentColor)] bg-[length:0%_1px] bg-left-bottom bg-no-repeat transition-[background-size] duration-700 ease-[var(--ease-out-soft)] group-hover:bg-[length:100%_1px]">
              {p.title}
            </span>
          </h3>
          <dl className="mt-5 grid grid-cols-3 border-t border-line text-[0.8125rem]">
            <div className="pt-3 pr-3">
              <dt className="sr-only">Prix</dt>
              <dd className="font-medium tabular-nums">{compactPrice(p)}</dd>
            </div>
            <div className="border-l border-line pt-3 pl-3">
              <dt className="sr-only">Surface</dt>
              <dd className="tabular-nums text-moss">{surface ? `${surface} m²` : "Surface sur demande"}</dd>
            </div>
            <div className="border-l border-line pt-3 pl-3">
              <dt className="sr-only">Chambres ou pièces</dt>
              <dd className="text-moss">
                {p.bedrooms
                  ? `${p.bedrooms} chambre${p.bedrooms > 1 ? "s" : ""}`
                  : p.rooms
                    ? `${p.rooms} pièces`
                    : "—"}
              </dd>
            </div>
          </dl>
        </div>
      </Link>
    </article>
  );
}
