/**
 * Catalogue des biens.
 *
 * Chaque fiche reprend fidèlement une annonce publiée par l'agence sur Instagram
 * (lien `source`). Aucune donnée n'a été ajoutée : lorsqu'une information
 * (prix, surface…) n'est pas publiée, le champ est laissé vide et le site affiche
 * « sur demande ».
 *
 * Les photographies sont des visuels d'ambiance (Unsplash) en attendant les
 * photos HD des biens : remplacez simplement les fichiers dans /public/images.
 */

export type Transaction = "vente" | "location";
export type PropertyType = "villa" | "appartement" | "bureau";

export type Property = {
  slug: string;
  title: string;
  /** Accroche éditoriale courte, tirée de l'annonce */
  tagline: string;
  transactions: Transaction[];
  type: PropertyType;
  /** Libellé affiché du type (ex. « Appartement S+2 ») */
  typeLabel: string;
  zone: ZoneId;
  district: string;
  price?: { sale?: number; rent?: number; rentPeriod?: "mois" };
  surface?: { living?: number; total?: number; land?: number; covered?: number };
  bedrooms?: number;
  rooms?: number;
  furnished?: boolean;
  floor?: string;
  description: string[];
  layout?: { title: string; items: string[] }[];
  features: string[];
  images: { src: string; alt: string }[];
  source: string;
  publishedAt: string;
};

export type ZoneId = "port-el-kantaoui" | "hammam-sousse" | "sousse" | "chott-mariem";

export const zones: Record<
  ZoneId,
  { name: string; short: string; description: string }
> = {
  "port-el-kantaoui": {
    name: "Port El Kantaoui",
    short: "La marina",
    description:
      "Station balnéaire organisée autour de sa marina, au nord de Sousse. Résidences, villas et bureaux avec vue sur la Méditerranée.",
  },
  "hammam-sousse": {
    name: "Hammam Sousse",
    short: "Le cœur de l'agence",
    description:
      "Notre adresse, sur la route touristique. Quartiers résidentiels comme Soviva et plateaux professionnels en zone touristique.",
  },
  sousse: {
    name: "Sousse",
    short: "La ville",
    description:
      "De Khezama, quartier résidentiel recherché, au secteur Panorama de la zone touristique, face à la mer.",
  },
  "chott-mariem": {
    name: "Chott Mariem",
    short: "Le littoral nord",
    description:
      "Plus au nord, un cadre de vie plus calme sur la côte, apprécié pour les locations à l'année.",
  },
};

export const typeLabels: Record<PropertyType, string> = {
  villa: "Villa",
  appartement: "Appartement",
  bureau: "Bureau",
};

export const properties: Property[] = [
  {
    slug: "villa-port-el-kantaoui",
    title: "Villa à deux minutes du port",
    tagline: "Une propriété que l'on trouve rarement.",
    transactions: ["vente"],
    type: "villa",
    typeLabel: "Villa de style américain",
    zone: "port-el-kantaoui",
    district: "Port El Kantaoui",
    surface: { land: 859, covered: 610 },
    bedrooms: 5,
    description: [
      "À seulement deux minutes à pied du Port El Kantaoui, cette villa de style américain réunit grands espaces, piscine et emplacement privilégié.",
      "Conçue pour vivre et recevoir, elle s'organise sur trois niveaux : un côté jour généreux ouvert sur un patio avec fontaine, un côté nuit avec suite parentale complète, et un sous-sol indépendant avec garage pour quatre voitures.",
      "À quelques pas du port, elle offre toute l'intimité et le confort d'une grande propriété privée.",
    ],
    layout: [
      {
        title: "Côté jour",
        items: ["2 salons", "Salle à manger", "Séjour", "Cuisine", "WC invités", "Patio avec fontaine"],
      },
      {
        title: "Côté nuit",
        items: [
          "3 chambres",
          "Salle de bain",
          "Grande suite parentale avec chambre, salon privé, salle de bain et dressing",
        ],
      },
      {
        title: "Sous-sol",
        items: ["Séjour", "Chambre", "Cuisine", "WC + douche", "Garage 4 voitures"],
      },
    ],
    features: [
      "Chauffage central",
      "Climatisation centrale",
      "Panneaux solaires",
      "Piscine extérieure",
      "Bar piscine",
      "Jardin gazonné",
      "2 terrasses extérieures",
    ],
    images: [
      { src: "/images/villa-1.webp", alt: "Façade d'une villa blanche avec piscine et palmiers" },
      { src: "/images/villa-2.webp", alt: "Piscine éclairée au crépuscule" },
      { src: "/images/villa-3.webp", alt: "Salon lumineux aux tons naturels" },
      { src: "/images/villa-4.webp", alt: "Séjour ouvert sur l'extérieur" },
      { src: "/images/villa-5.webp", alt: "Suite parentale" },
      { src: "/images/villa-6.webp", alt: "Piscine et terrasse" },
    ],
    source: "https://www.instagram.com/p/Db3QjLIDAYE/",
    publishedAt: "2026-08-10",
  },
  {
    slug: "plateau-bureau-hammam-sousse",
    title: "Plateau open space, zone touristique",
    tagline: "Une adresse stratégique pour votre entreprise.",
    transactions: ["vente", "location"],
    type: "bureau",
    typeLabel: "Plateau de bureaux",
    zone: "hammam-sousse",
    district: "Zone touristique, Hammam Sousse",
    price: { sale: 750000, rent: 3500, rentPeriod: "mois" },
    surface: { living: 131, total: 151 },
    rooms: 4,
    description: [
      "Au cœur de la zone touristique de Hammam Sousse, un plateau de bureaux en open space modulable, proposé à la vente ou à la location.",
      "Avec ses quatre pièces, sa kitchenette et ses deux places de parking, il convient aussi bien à des bureaux qu'à un cabinet ou un siège d'entreprise.",
    ],
    features: [
      "Open space modulable",
      "4 pièces",
      "Kitchenette",
      "2 sanitaires",
      "2 places de parking",
      "Emplacement premium",
    ],
    images: [
      { src: "/images/bureau-1.webp", alt: "Plateau de bureaux lumineux" },
      { src: "/images/bureau-2.webp", alt: "Open space aux grandes baies vitrées" },
      { src: "/images/interior.webp", alt: "Espace de réception" },
    ],
    source: "https://www.instagram.com/p/DbVPCjBjPAc/",
    publishedAt: "2026-07-28",
  },
  {
    slug: "appartement-s1-kantaoui",
    title: "Appartement S+1 en résidence",
    tagline: "Un pied-à-terre ou un investissement locatif.",
    transactions: ["vente"],
    type: "appartement",
    typeLabel: "Appartement S+1",
    zone: "port-el-kantaoui",
    district: "Kantaoui",
    price: { sale: 350000 },
    surface: { living: 58, total: 75 },
    bedrooms: 1,
    floor: "1er étage",
    description: [
      "Dans l'un des quartiers les plus prisés de Kantaoui, un S+1 confortable situé au premier étage d'une résidence.",
      "Un bien idéal pour une résidence principale, un pied-à-terre ou un investissement locatif.",
    ],
    layout: [
      {
        title: "Intérieur",
        items: ["Salon lumineux", "1 chambre à coucher", "Cuisine fonctionnelle", "Salle de douche"],
      },
    ],
    features: ["Balcon", "Séchoir", "Place de parking privative au sous-sol", "Résidence"],
    images: [
      { src: "/images/s1-1.webp", alt: "Salon lumineux d'un appartement" },
      { src: "/images/s1-2.webp", alt: "Cuisine fonctionnelle" },
      { src: "/images/s1-3.webp", alt: "Chambre à coucher" },
    ],
    source: "https://www.instagram.com/p/DbTNYbzjKVX/",
    publishedAt: "2026-07-27",
  },
  {
    slug: "appartement-s2-panorama-sousse",
    title: "S+2 meublé, vue sur mer",
    tagline: "Le confort et le charme de la côte.",
    transactions: ["location"],
    type: "appartement",
    typeLabel: "Appartement S+2",
    zone: "sousse",
    district: "Panorama, zone touristique de Sousse",
    bedrooms: 2,
    furnished: true,
    description: [
      "Au cœur du secteur prisé de Panorama, dans la zone touristique de Sousse, un S+2 richement meublé avec balcon privatif face à la mer.",
      "Un cadre idéal pour profiter pleinement du confort et du charme de la côte.",
    ],
    layout: [
      {
        title: "Intérieur",
        items: [
          "Salon spacieux et lumineux",
          "2 chambres à coucher",
          "Cuisine équipée et séchoir",
          "Salle de bain",
        ],
      },
    ],
    features: ["Richement meublé", "Balcon privatif vue sur mer", "Emplacement stratégique"],
    images: [
      { src: "/images/panorama-1.webp", alt: "Séjour ouvert sur la mer" },
      { src: "/images/panorama-2.webp", alt: "Salon meublé" },
      { src: "/images/panorama-3.webp", alt: "Chambre lumineuse" },
    ],
    source: "https://www.instagram.com/p/DbqZ68ODD9N/",
    publishedAt: "2026-08-05",
  },
  {
    slug: "appartement-s3-khezama",
    title: "S+3 avec jardin privatif",
    tagline: "Un cocon familial, et un atout rare.",
    transactions: ["location"],
    type: "appartement",
    typeLabel: "Appartement S+3",
    zone: "sousse",
    district: "Khezama",
    bedrooms: 3,
    furnished: false,
    floor: "1er étage",
    description: [
      "Dans le quartier recherché de Khezama, un appartement spacieux et non meublé au premier étage, doté de trois balcons.",
      "Un agencement pensé pour la famille — hall d'entrée, cuisine indépendante, deux sanitaires — et un atout rare : un jardin privatif.",
    ],
    layout: [
      {
        title: "Intérieur",
        items: [
          "Hall d'entrée",
          "Cuisine indépendante",
          "3 chambres",
          "Salle de bain + salle d'eau",
        ],
      },
    ],
    features: ["3 balcons", "Jardin privatif", "Abri de voiture couvert", "Non meublé"],
    images: [
      { src: "/images/khezama-1.webp", alt: "Séjour spacieux" },
      { src: "/images/khezama-2.webp", alt: "Salon aux tons clairs" },
      { src: "/images/khezama-3.webp", alt: "Chambre" },
      { src: "/images/khezama-4.webp", alt: "Coin repas" },
    ],
    source: "https://www.instagram.com/p/DbnxAK7jOpN/",
    publishedAt: "2026-08-04",
  },
  {
    slug: "bureaux-vue-mer-el-kantaoui",
    title: "Bureaux avec vue sur mer",
    tagline: "Un cadre de travail lumineux et modulable.",
    transactions: ["location"],
    type: "bureau",
    typeLabel: "Bureaux",
    zone: "port-el-kantaoui",
    district: "El Kantaoui",
    rooms: 3,
    furnished: false,
    floor: "2e étage",
    description: [
      "Au deuxième étage, à El Kantaoui, des bureaux non meublés baignés de lumière, avec vue sur mer.",
      "Trois grandes pièces à aménager librement, pour concevoir un espace professionnel à votre image.",
    ],
    features: [
      "Vue sur mer",
      "3 pièces principales",
      "Climatisation et chauffage central",
      "2 balcons",
      "Grande cuisine",
      "Salle de bain et salle d'eau",
    ],
    images: [
      { src: "/images/kantaoui-bureau-1.webp", alt: "Bureau clair aux murs blancs" },
      { src: "/images/kantaoui-bureau-2.webp", alt: "Salle d'eau" },
      { src: "/images/bureau-2.webp", alt: "Espace de travail ouvert" },
    ],
    source: "https://www.instagram.com/p/Dbnby61DH56/",
    publishedAt: "2026-08-04",
  },
  {
    slug: "appartement-s2-soviva",
    title: "S+2 meublé à Soviva",
    tagline: "Prêt à habiter, en location à l'année.",
    transactions: ["location"],
    type: "appartement",
    typeLabel: "Appartement S+2",
    zone: "hammam-sousse",
    district: "Soviva, Hammam Sousse",
    bedrooms: 2,
    furnished: true,
    description: [
      "Dans le secteur recherché de Soviva, à Hammam Sousse, un S+2 entièrement meublé, confortable et fonctionnel.",
      "Idéal pour une habitation principale : location annuelle, bail longue durée.",
    ],
    layout: [
      {
        title: "Intérieur",
        items: [
          "2 salons spacieux et lumineux",
          "2 chambres à coucher",
          "Cuisine entièrement équipée",
          "Salle de bain",
        ],
      },
    ],
    features: ["Entièrement meublé", "Séchoir indépendant", "Location annuelle", "Bail longue durée"],
    images: [
      { src: "/images/soviva-1.webp", alt: "Salon lumineux" },
      { src: "/images/soviva-2.webp", alt: "Coin salon" },
      { src: "/images/soviva-3.webp", alt: "Chambre à coucher" },
    ],
    source: "https://www.instagram.com/p/DblHuVnjNpQ/",
    publishedAt: "2026-08-03",
  },
  {
    slug: "appartement-s2-chott-mariem",
    title: "S+2 meublé, deux balcons",
    tagline: "Posez vos valises, tout est prêt.",
    transactions: ["location"],
    type: "appartement",
    typeLabel: "Appartement S+2",
    zone: "chott-mariem",
    district: "Chott Mariem",
    bedrooms: 2,
    furnished: true,
    description: [
      "À Chott Mariem, un appartement S+2 clé en main, entièrement meublé et disponible immédiatement.",
      "Un salon, deux chambres et deux balcons privatifs pour profiter du grand air, dans un cadre de vie agréable.",
    ],
    features: ["Entièrement meublé", "Salon + 2 chambres", "2 balcons privatifs", "Disponible immédiatement"],
    images: [
      { src: "/images/chott-1.webp", alt: "Séjour meublé" },
      { src: "/images/chott-2.webp", alt: "Salon lumineux" },
      { src: "/images/chott-3.webp", alt: "Chambre" },
    ],
    source: "https://www.instagram.com/p/DbqkE3GjFNW/",
    publishedAt: "2026-08-05",
  },
];

export function getProperty(slug: string) {
  return properties.find((p) => p.slug === slug);
}

export function transactionLabel(p: Property) {
  if (p.transactions.length > 1) return "Vente ou location";
  return p.transactions[0] === "vente" ? "À vendre" : "À louer";
}

const nf = new Intl.NumberFormat("fr-FR");
export function formatTND(n: number) {
  return `${nf.format(n).replace(/ | /g, " ")} DT`;
}

export function priceLabel(p: Property) {
  if (p.price?.sale && p.price?.rent)
    return `${formatTND(p.price.sale)} · ${formatTND(p.price.rent)} / mois`;
  if (p.price?.sale) return formatTND(p.price.sale);
  if (p.price?.rent) return `${formatTND(p.price.rent)} / mois`;
  return "Prix sur demande";
}

/** Version courte pour les cartes. */
export function compactPrice(p: Property) {
  if (p.price?.sale) return formatTND(p.price.sale);
  if (p.price?.rent) return `${formatTND(p.price.rent)}/mois`;
  return "Prix sur demande";
}

export function surfaceLabel(p: Property) {
  const s = p.surface;
  if (!s) return undefined;
  if (s.covered && s.land) return `${s.covered} m² couverts · ${s.land} m² de terrain`;
  if (s.living && s.total) return `${s.living} m² habitables · ${s.total} m² au total`;
  if (s.living) return `${s.living} m²`;
  return undefined;
}

export function mainSurface(p: Property) {
  return p.surface?.covered ?? p.surface?.living;
}
