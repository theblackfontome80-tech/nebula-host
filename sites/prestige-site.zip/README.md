# Prestige Immobilier — site web

Site de l'Agence Prestige Immobilier (Hammam Sousse). Next.js 16 · TypeScript · Tailwind CSS 4 · Framer Motion · Lenis.

## Lancer

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start   # production
```

Avant la mise en ligne, définir le domaine : `NEXT_PUBLIC_SITE_URL=https://votre-domaine.tn` (utilisé par le sitemap, les balises canoniques et Open Graph).

## Où modifier le contenu

| Quoi | Fichier |
| --- | --- |
| Coordonnées, téléphones, WhatsApp, Instagram, carte | `src/lib/agency.ts` |
| Biens (ajout, prix, surfaces, photos) et secteurs | `src/lib/properties.ts` |
| Photos | `public/images/` |

### Sources des informations

- **Coordonnées** : fiche Google Maps de l'agence et bio Instagram (`@agence_prestige_immobilier`).
- **Biens** : chaque fiche reprend une annonce Instagram de l'agence (champ `source`). Quand l'annonce ne donne ni prix ni surface, le site affiche « sur demande ».
- **Photos** : visuels d'ambiance (Unsplash), signalés comme tels sur le site. Remplacez-les par les vraies photos des biens en gardant les mêmes noms de fichiers, ou modifiez le champ `images` de chaque bien.

### À vérifier par l'agence

- Le bouton WhatsApp pointe vers le **52 347 097** (`agency.whatsapp`). Vérifiez que ce numéro est bien sur WhatsApp.
- Le formulaire de contact n'a pas de serveur : il ouvre WhatsApp avec le message déjà rédigé. Pour recevoir les messages par e-mail, branchez un service (Resend, Formspree…) dans `src/components/contact-form.tsx`.

## Structure

```
src/app/            pages : accueil, /biens, /biens/[slug], /agence, /contact, sitemap, robots
src/components/     en-tête, pied de page, cartes, recherche, galerie, animations
src/lib/            données (agence, biens) et utilitaires
```
