"use client";

import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { useId, useState, type FormEvent, type ReactNode } from "react";
import { agency, whatsappLink } from "@/lib/agency";
import { cn } from "@/lib/cn";
import { getProperty } from "@/lib/properties";

const subjects = [
  { value: "achat", label: "Acheter un bien" },
  { value: "location", label: "Louer un bien" },
  { value: "vente", label: "Vendre mon bien" },
  { value: "mise-en-location", label: "Mettre mon bien en location" },
  { value: "estimation", label: "Faire estimer mon bien" },
  { value: "recherche", label: "Confier une recherche" },
  { value: "bien", label: "Un bien en particulier" },
];

/**
 * Formulaire de contact.
 * Le site n'ayant pas de serveur de messagerie, l'envoi compose un message
 * WhatsApp pré-rempli adressé à l'agence (aucune donnée n'est stockée).
 */
export function ContactForm() {
  const params = useSearchParams();
  const property = getProperty(params.get("bien") ?? "");
  const initialSubject = property
    ? "bien"
    : subjects.some((s) => s.value === params.get("objet"))
      ? (params.get("objet") as string)
      : "achat";

  const [subject, setSubject] = useState(initialSubject);
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const phone = String(data.get("phone") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();

    const errs: Record<string, string> = {};
    if (name.length < 2) errs.name = "Indiquez votre nom.";
    if (phone.replace(/\D/g, "").length < 8) errs.phone = "Indiquez un numéro joignable.";
    setErrors(errs);
    if (Object.keys(errs).length) {
      (e.currentTarget.querySelector(`[name="${Object.keys(errs)[0]}"]`) as HTMLElement | null)?.focus();
      return;
    }

    const subjectLabel = subjects.find((s) => s.value === subject)?.label ?? "";
    const lines = [
      `Bonjour ${agency.shortName},`,
      "",
      `Objet : ${subjectLabel}${property && subject === "bien" ? ` — ${property.title} (${property.district})` : ""}`,
      ...(message ? [`Message : ${message}`] : []),
      "",
      `${name} — ${phone}`,
    ];

    window.open(whatsappLink(lines.join("\n")), "_blank", "noopener,noreferrer");
    setSent(true);
  }

  return (
    <form onSubmit={submit} noValidate className="grid gap-x-8 gap-y-2 md:grid-cols-2">
      <fieldset className="md:col-span-2">
        <legend className="eyebrow mb-5 text-moss">Votre demande</legend>
        <div className="flex flex-wrap gap-2">
          {subjects
            .filter((s) => s.value !== "bien" || property)
            .map((s) => (
              <label key={s.value} className="cursor-pointer">
                <input
                  type="radio"
                  name="subject"
                  value={s.value}
                  checked={subject === s.value}
                  onChange={() => setSubject(s.value)}
                  className="peer sr-only"
                />
                <span
                  className={cn(
                    "inline-block border px-4 py-2 text-[0.8125rem] transition-colors duration-300 peer-focus-visible:outline peer-focus-visible:outline-1 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-clay",
                    subject === s.value
                      ? "border-ink bg-ink text-chalk"
                      : "border-line text-moss hover:border-ink/40 hover:text-ink",
                  )}
                >
                  {s.value === "bien" && property ? property.title : s.label}
                </span>
              </label>
            ))}
        </div>
      </fieldset>

      <div className="mt-8 md:col-span-1">
        <Field name="name" label="Nom et prénom" autoComplete="name" error={errors.name} />
      </div>
      <div className="mt-8 md:col-span-1">
        <Field name="phone" label="Téléphone" type="tel" autoComplete="tel" inputMode="tel" error={errors.phone} />
      </div>
      <div className="md:col-span-2">
        <Field
          name="message"
          label="Message (facultatif)"
          textarea
          defaultValue={
            property
              ? `Je souhaite obtenir des informations et organiser une visite pour « ${property.title} ».`
              : ""
          }
        />
      </div>

      <div className="mt-6 flex flex-col gap-5 md:col-span-2 md:flex-row md:items-center md:justify-between">
        <p className="max-w-sm text-[0.8125rem] leading-relaxed text-moss">
          L&apos;envoi ouvre WhatsApp avec votre message pré-rempli, adressé directement à
          l&apos;agence. Aucune donnée n&apos;est conservée sur ce site.
        </p>
        <button
          type="submit"
          className="group inline-flex items-center justify-between gap-6 bg-olive px-8 py-5 text-[0.75rem] tracking-[0.16em] text-chalk uppercase transition-colors hover:bg-ink"
        >
          Envoyer via WhatsApp
          <svg width="22" height="10" viewBox="0 0 22 10" fill="none" aria-hidden className="transition-transform duration-500 group-hover:translate-x-1">
            <path d="M0 5h20m0 0-4-4m4 4-4 4" stroke="currentColor" strokeWidth="1" />
          </svg>
        </button>
      </div>

      <div aria-live="polite" className="md:col-span-2">
        {sent && (
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 border-l border-clay pl-4 text-[0.9375rem]"
          >
            Votre message est prêt dans WhatsApp : il ne reste qu&apos;à l&apos;envoyer. Vous pouvez
            aussi appeler le{" "}
            <a className="underline underline-offset-4" href={`tel:${agency.phones[1].tel}`}>
              {agency.phones[1].display}
            </a>
            .
          </motion.p>
        )}
      </div>
    </form>
  );
}

function Field({
  name,
  label,
  textarea,
  error,
  ...rest
}: {
  name: string;
  label: string;
  textarea?: boolean;
  error?: string;
  type?: string;
  autoComplete?: string;
  inputMode?: "tel" | "text";
  defaultValue?: string;
}): ReactNode {
  const id = useId();
  const cls =
    "peer block w-full border-b bg-transparent pt-7 pb-3 text-[1.0625rem] outline-none transition-colors placeholder-transparent focus:border-ink";
  return (
    <div className="relative">
      {textarea ? (
        <textarea id={id} name={name} rows={4} placeholder=" " className={cn(cls, "resize-none border-line")} {...rest} />
      ) : (
        <input
          id={id}
          name={name}
          placeholder=" "
          aria-invalid={Boolean(error)}
          aria-describedby={error ? `${id}-err` : undefined}
          className={cn(cls, error ? "border-clay" : "border-line")}
          {...rest}
        />
      )}
      <label
        htmlFor={id}
        className="pointer-events-none absolute top-7 left-0 origin-left text-[1.0625rem] text-moss transition-all duration-300 ease-[var(--ease-out-soft)] peer-focus:top-1 peer-focus:scale-[0.72] peer-[:not(:placeholder-shown)]:top-1 peer-[:not(:placeholder-shown)]:scale-[0.72]"
      >
        {label}
      </label>
      {error && (
        <p id={`${id}-err`} className="mt-2 text-[0.8125rem] text-clay">
          {error}
        </p>
      )}
    </div>
  );
}
