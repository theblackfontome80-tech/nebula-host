import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter_Tight } from "next/font/google";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { SmoothScroll } from "@/components/smooth-scroll";
import { agency, siteUrl } from "@/lib/agency";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  style: ["normal", "italic"],
  display: "swap",
});

const interTight = Inter_Tight({
  variable: "--font-inter-tight",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Prestige Immobilier — Agence immobilière à Hammam Sousse",
    template: "%s — Prestige Immobilier",
  },
  description:
    "Agence Prestige Immobilier, Hammam Sousse : vente, location et estimation de villas, appartements et bureaux à Port El Kantaoui, Sousse et Chott Mariem.",
  keywords: [
    "agence immobilière Sousse",
    "immobilier Hammam Sousse",
    "villa Port El Kantaoui",
    "location appartement Sousse",
    "estimation immobilière Tunisie",
  ],
  openGraph: {
    type: "website",
    locale: "fr_TN",
    siteName: agency.name,
    images: [{ url: "/images/hero.webp", width: 2400, height: 1600 }],
  },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = {
  themeColor: "#f2ede4",
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "RealEstateAgent",
  name: agency.name,
  url: siteUrl,
  telephone: agency.phones.map((p) => p.tel),
  address: {
    "@type": "PostalAddress",
    streetAddress: agency.address.street,
    addressLocality: agency.address.city,
    addressCountry: "TN",
  },
  geo: { "@type": "GeoCoordinates", latitude: agency.geo.lat, longitude: agency.geo.lng },
  sameAs: [agency.instagram.url, agency.mapsUrl],
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="fr" className={`${cormorant.variable} ${interTight.variable} antialiased`}>
      <body className="min-h-dvh flex flex-col">
        <a
          href="#contenu"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:bg-ink focus:px-4 focus:py-2 focus:text-chalk"
        >
          Aller au contenu
        </a>
        <SmoothScroll />
        <SiteHeader />
        <main id="contenu" className="flex-1">
          {children}
        </main>
        <SiteFooter />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}
