import Link from "next/link";
import { LineReveal, Reveal } from "@/components/motion";
import { agency, whatsappLink } from "@/lib/agency";

/** Bandeau de contact éditorial, en fin de page. */
export function ContactBand() {
  return (
    <section aria-label="Contact" className="bg-paper">
      <div className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-36">
        <div className="grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <Reveal className="mb-8 flex items-center gap-4 border-t border-line pt-4">
              <span className="numeral text-sm">—</span>
              <span className="eyebrow opacity-70">Votre projet</span>
            </Reveal>
            <LineReveal
              as="h2"
              lines={["Parlons de", <em key="e" className="italic">votre projet.</em>]}
              className="font-display text-[clamp(3rem,8vw,7.5rem)] leading-[0.92]"
            />
            <Reveal delay={0.2} className="mt-10 flex flex-wrap gap-4">
              <a
                href={whatsappLink("Bonjour Prestige Immobilier, je souhaite échanger au sujet d'un projet immobilier.")}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-4 bg-olive px-7 py-4 text-[0.75rem] tracking-[0.16em] text-chalk uppercase transition-colors hover:bg-ink"
              >
                Écrire sur WhatsApp
                <svg width="22" height="10" viewBox="0 0 22 10" fill="none" aria-hidden className="transition-transform duration-500 group-hover:translate-x-1">
                  <path d="M0 5h20m0 0-4-4m4 4-4 4" stroke="currentColor" strokeWidth="1" />
                </svg>
              </a>
              <Link
                href="/contact"
                className="inline-flex items-center border border-ink/30 px-7 py-4 text-[0.75rem] tracking-[0.16em] uppercase transition-colors hover:border-ink hover:bg-ink hover:text-chalk"
              >
                Formulaire de contact
              </Link>
            </Reveal>
          </div>

          <Reveal delay={0.15} className="grid content-end gap-10 sm:grid-cols-2 lg:col-span-5 lg:grid-cols-1">
            <div>
              <p className="eyebrow mb-4 text-moss">Par téléphone</p>
              <ul className="space-y-1">
                {agency.phones.map((p) => (
                  <li key={p.tel}>
                    <a href={`tel:${p.tel}`} className="font-display text-3xl tabular-nums link-underline md:text-4xl">
                      {p.display}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="eyebrow mb-4 text-moss">À l&apos;agence</p>
              <address className="not-italic text-[1.0625rem] leading-relaxed">
                {agency.address.street}
                <br />
                {agency.address.city}, {agency.address.country}
              </address>
              <p className="mt-2 text-sm text-moss">{agency.visits}</p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
