import Link from "next/link";
import { ContactBand } from "@/components/contact-band";
import { HomeHero } from "@/components/home-hero";
import { Reveal, RevealImage } from "@/components/motion";
import { PageTransition } from "@/components/page-transition";
import { PropertyCard } from "@/components/property-card";
import { SectionHeading } from "@/components/section-heading";
import { ServicesList } from "@/components/services-list";
import { Territory } from "@/components/territory";
import { agency } from "@/lib/agency";
import { getProperty, properties, type Property } from "@/lib/properties";

const featured = [
  "villa-port-el-kantaoui",
  "appartement-s2-panorama-sousse",
  "plateau-bureau-hammam-sousse",
  "appartement-s3-khezama",
].map((s) => getProperty(s)) as Property[];

const indexOf = (p: Property) => properties.indexOf(p) + 1;

export default function Home() {
  return (
    <PageTransition>
      <HomeHero />

      {/* Manifeste */}
      <section aria-label="Présentation" className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-40">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-3">
            <Reveal>
              <p className="eyebrow text-moss">{agency.instagramName}</p>
            </Reveal>
            <RevealImage
              src="/images/villa-3.webp"
              alt="Salon lumineux aux matières naturelles"
              sizes="(min-width:768px) 22vw, 100vw"
              className="mt-8 aspect-[3/4] max-md:max-w-xs"
              parallax={6}
              delay={0.1}
            />
            <Reveal delay={0.2}>
              <p className="mt-3 text-[0.75rem] text-moss">{agency.address.city} — {agency.address.country}</p>
            </Reveal>
          </div>
          <div className="md:col-span-8 md:col-start-5">
            <Reveal>
              <p className="font-display text-[clamp(1.85rem,3.6vw,3.4rem)] leading-[1.12]">
                Une agence de proximité installée sur la route touristique de Hammam&nbsp;Sousse.
                Nous accompagnons particuliers et professionnels <em className="italic text-moss">dans
                la vente, la location et l&apos;estimation</em> de villas, d&apos;appartements et de bureaux
                le long du littoral.
              </p>
            </Reveal>
            <Reveal delay={0.1} className="mt-14 grid gap-px border-t border-line sm:grid-cols-3">
              {[
                ["Vente · Location · Estimation", "Trois métiers, un seul interlocuteur."],
                ["Particuliers & professionnels", "Résidences, villas, plateaux de bureaux."],
                [agency.visits, "Chaque visite est préparée et accompagnée."],
              ].map(([t, d]) => (
                <div key={t} className="pt-5 pr-6">
                  <p className="text-[0.9375rem] font-medium">{t}</p>
                  <p className="mt-1.5 text-[0.875rem] text-moss">{d}</p>
                </div>
              ))}
            </Reveal>
          </div>
        </div>
      </section>

      {/* Sélection */}
      <section aria-label="Sélection de biens" className="mx-auto max-w-[1600px] px-5 pb-24 md:px-10 md:pb-40">
        <SectionHeading
          index="01"
          label="Sélection"
          title={["Biens du moment,", <em key="e" className="italic">de la marina à Khezama.</em>]}
          aside={
            <div className="flex flex-col items-start gap-5 md:items-end md:text-right">
              <p className="max-w-xs text-[0.9375rem] leading-relaxed text-moss">
                Les annonces récemment confiées à l&apos;agence, à la vente comme à la location.
              </p>
              <Link href="/biens" className="text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                Tous les biens ({properties.length})
              </Link>
            </div>
          }
        />

        <div className="mt-16 grid gap-x-8 gap-y-16 md:mt-24 md:grid-cols-12 md:gap-y-28">
          <Reveal className="md:col-span-7">
            <PropertyCard property={featured[0]} index={indexOf(featured[0])} aspect="aspect-[4/3]" sizes="(min-width:768px) 58vw, 100vw" />
          </Reveal>
          <Reveal delay={0.12} className="md:col-span-4 md:col-start-9 md:mt-40">
            <PropertyCard property={featured[1]} index={indexOf(featured[1])} sizes="(min-width:768px) 33vw, 100vw" />
          </Reveal>
          <Reveal className="md:col-span-4 md:col-start-2">
            <PropertyCard property={featured[2]} index={indexOf(featured[2])} sizes="(min-width:768px) 33vw, 100vw" />
          </Reveal>
          <Reveal delay={0.12} className="md:col-span-6 md:col-start-7 md:-mt-24">
            <PropertyCard property={featured[3]} index={indexOf(featured[3])} aspect="aspect-[5/4]" sizes="(min-width:768px) 50vw, 100vw" />
          </Reveal>
        </div>
      </section>

      {/* L'agence */}
      <section aria-label="L'agence" className="border-t border-line bg-paper">
        <div className="mx-auto grid max-w-[1600px] gap-12 px-5 py-24 md:grid-cols-12 md:px-10 md:py-36">
          <div className="md:col-span-5 md:col-start-1">
            <RevealImage
              src="/images/white.webp"
              alt="Architecture méditerranéenne blanche baignée de lumière"
              sizes="(min-width:768px) 40vw, 100vw"
              className="aspect-[3/4]"
              parallax={6}
            />
          </div>
          <div className="flex flex-col md:col-span-6 md:col-start-7">
            <SectionHeading
              index="02"
              label="L'agence"
              title={["Votre partenaire", <em key="e" className="italic">de confiance.</em>]}
              stacked
            />
            <Reveal delay={0.1} className="mt-10 space-y-5 text-[1.0625rem] leading-relaxed text-moss">
              <p>
                Prestige Immobilier Tunisie est une agence immobilière établie à Hammam Sousse,
                sur le boulevard du 14 Janvier. Notre métier : rapprocher les bons biens des bonnes
                personnes, avec méthode et discrétion.
              </p>
              <p>
                Nous connaissons chaque secteur que nous présentons — ses rues, ses résidences, ses
                vues sur mer — et nous accompagnons nos clients du premier échange jusqu&apos;à la remise
                des clés.
              </p>
            </Reveal>
            <Reveal delay={0.2} className="mt-auto pt-12">
              <blockquote className="border-l border-clay pl-6">
                <p className="font-display text-2xl leading-snug italic md:text-[1.75rem]">
                  « Votre confort, notre priorité. »
                </p>
              </blockquote>
              <Link href="/agence" className="mt-10 inline-block text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1">
                Découvrir l&apos;agence
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Expertise */}
      <section id="expertise" aria-label="Expertise" className="scroll-mt-24">
        <div className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-36">
          <SectionHeading
            index="03"
            label="Expertise"
            title={["Ce que nous faisons,", <em key="e" className="italic">et comment.</em>]}
            aside={
              <p className="max-w-xs text-[0.9375rem] leading-relaxed text-moss md:ml-auto">
                Un accompagnement complet, que vous cherchiez un logement, un investissement ou des
                bureaux.
              </p>
            }
          />
          <div className="mt-16 md:mt-24">
            <ServicesList />
          </div>
        </div>
      </section>

      {/* Territoire */}
      <section aria-label="Nos secteurs" className="grain relative bg-olive text-chalk">
        <div className="relative mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-36">
          <SectionHeading
            index="04"
            label="Territoire"
            tone="light"
            title={["Le littoral du Sahel,", <em key="e" className="italic">rue après rue.</em>]}
            aside={
              <p className="max-w-xs text-[0.9375rem] leading-relaxed text-chalk/70 md:ml-auto">
                Quatre secteurs, de Sousse à Chott Mariem, où l&apos;agence présente ses biens.
              </p>
            }
          />
          <div className="mt-16 md:mt-24">
            <Territory />
          </div>
        </div>
      </section>

      <ContactBand />
    </PageTransition>
  );
}
