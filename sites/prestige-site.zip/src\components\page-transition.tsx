import { ViewTransition, type ReactNode } from "react";

/**
 * Enveloppe chaque page : fondu sortant puis montée douce de la nouvelle page.
 * Placée dans les page.tsx (et non le layout) pour que enter/exit se déclenchent.
 */
export function PageTransition({ children }: { children: ReactNode }) {
  return (
    <ViewTransition enter="page-enter" exit="page-exit" default="none">
      <div>{children}</div>
    </ViewTransition>
  );
}
