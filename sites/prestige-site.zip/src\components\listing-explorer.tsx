"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useRef } from "react";
import { PropertyCard } from "@/components/property-card";
import { cn } from "@/lib/cn";
import {
  properties,
  typeLabels,
  zones,
  type PropertyType,
  type Transaction,
  type ZoneId,
} from "@/lib/properties";

const transactions: { value: "" | Transaction; label: string }[] = [
  { value: "", label: "Tous" },
  { value: "vente", label: "Acheter" },
  { value: "location", label: "Louer" },
];

function pick<T extends string>(value: string | null, allowed: readonly T[]): T | "" {
  return value && (allowed as readonly string[]).includes(value) ? (value as T) : "";
}

export function ListingExplorer() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const rootRef = useRef<HTMLDivElement>(null);

  const transaction = pick(params.get("transaction"), ["vente", "location"] as const);
  const type = pick(params.get("type"), Object.keys(typeLabels) as PropertyType[]);
  const zone = pick(params.get("zone"), Object.keys(zones) as ZoneId[]);

  const results = useMemo(
    () =>
      properties.filter(
        (p) =>
          (!transaction || p.transactions.includes(transaction)) &&
          (!type || p.type === type) &&
          (!zone || p.zone === zone),
      ),
    [transaction, type, zone],
  );

  function update(key: string, value: string) {
    const next = new URLSearchParams(params.toString());
    if (value) next.set(key, value);
    else next.delete(key);
    const qs = next.toString();
    router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    // Ramener la barre de filtres à l'écran si l'utilisateur a défilé plus bas
    const top = rootRef.current?.getBoundingClientRect().top ?? 0;
    if (top < 0) window.scrollTo({ top: window.scrollY + top - 96, behavior: "smooth" });
  }

  const hasFilters = Boolean(transaction || type || zone);

  return (
    <div ref={rootRef} className="min-h-[70vh]">
      {/* Barre de filtres */}
      <div className="-mx-5 border-y border-line px-5 md:-mx-10 md:px-10">
        <div className="flex flex-col gap-4 py-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="no-scrollbar -mx-5 flex items-center gap-8 overflow-x-auto px-5 lg:mx-0 lg:px-0">
            <FilterGroup label="Transaction">
              {transactions.map((t) => (
                <Chip group="tx" key={t.label} active={transaction === t.value} onClick={() => update("transaction", t.value)}>
                  {t.label}
                </Chip>
              ))}
            </FilterGroup>
            <span className="h-5 w-px shrink-0 bg-line" aria-hidden />
            <FilterGroup label="Type de bien">
              <Chip group="type" active={!type} onClick={() => update("type", "")}>
                Tous types
              </Chip>
              {(Object.keys(typeLabels) as PropertyType[]).map((k) => (
                <Chip group="type" key={k} active={type === k} onClick={() => update("type", k)}>
                  {typeLabels[k]}s
                </Chip>
              ))}
            </FilterGroup>
          </div>

          <div className="flex items-center justify-between gap-6">
            <label className="relative flex items-center gap-3 text-[0.8125rem]">
              <span className="eyebrow text-[0.625rem] text-moss">Secteur</span>
              <select
                value={zone}
                onChange={(e) => update("zone", e.target.value)}
                className="cursor-pointer appearance-none border-b border-ink/30 bg-transparent py-1 pr-6 outline-none"
              >
                <option value="">Tout le littoral</option>
                {Object.entries(zones).map(([k, z]) => (
                  <option key={k} value={k}>
                    {z.name}
                  </option>
                ))}
              </select>
              <svg className="pointer-events-none absolute right-0" width="10" height="6" viewBox="0 0 10 6" fill="none" aria-hidden>
                <path d="m1 1 4 4 4-4" stroke="currentColor" strokeWidth="1" />
              </svg>
            </label>
            <p className="text-[0.8125rem] tabular-nums text-moss" aria-live="polite">
              <span className="numeral text-base text-ink">{results.length}</span> bien{results.length > 1 ? "s" : ""}
            </p>
          </div>
        </div>
      </div>

      {/* Résultats */}
      <motion.ul layout className="mt-14 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 md:mt-20">
        <AnimatePresence mode="popLayout" initial={false}>
          {results.map((p, i) => (
            <motion.li
              key={p.slug}
              layout
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: Math.min(i, 5) * 0.05 }}
              className={cn(i % 3 === 1 && "lg:mt-24")}
            >
              <PropertyCard property={p} index={properties.indexOf(p) + 1} priority={i < 3} />
            </motion.li>
          ))}
        </AnimatePresence>
      </motion.ul>

      {results.length === 0 && (
        <div className="border-t border-line py-24 text-center">
          <p className="font-display text-3xl md:text-4xl">Aucun bien ne correspond à cette recherche.</p>
          <p className="mx-auto mt-4 max-w-md text-moss">
            Notre portefeuille évolue régulièrement : confiez-nous votre recherche, nous vous
            contacterons dès qu&apos;un bien correspond.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <button
              type="button"
              onClick={() => router.replace(pathname, { scroll: false })}
              className="border border-ink/30 px-6 py-3 text-[0.75rem] tracking-[0.14em] uppercase hover:bg-ink hover:text-chalk"
            >
              Réinitialiser
            </button>
            <Link
              href="/contact?objet=recherche"
              className="bg-olive px-6 py-3 text-[0.75rem] tracking-[0.14em] text-chalk uppercase hover:bg-ink"
            >
              Confier ma recherche
            </Link>
          </div>
        </div>
      )}

      {hasFilters && results.length > 0 && (
        <div className="mt-20 text-center">
          <button
            type="button"
            onClick={() => router.replace(pathname, { scroll: false })}
            className="text-[0.75rem] tracking-[0.16em] uppercase link-underline pb-1"
          >
            Voir tous les biens
          </button>
        </div>
      )}
    </div>
  );
}

function FilterGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div role="group" aria-label={label} className="flex shrink-0 items-center gap-1">
      {children}
    </div>
  );
}

function Chip({
  group,
  active,
  onClick,
  children,
}: {
  group: string;
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "relative shrink-0 px-3 py-1.5 text-[0.8125rem] transition-colors duration-300",
        active ? "text-ink" : "text-moss hover:text-ink",
      )}
    >
      {active && (
        <motion.span
          layoutId={`chip-${group}`}
          className="absolute inset-x-3 bottom-0 h-px bg-ink"
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        />
      )}
      {children}
    </button>
  );
}
