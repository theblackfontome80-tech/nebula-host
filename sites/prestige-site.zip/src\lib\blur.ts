import blurMap from "./image-blur.json";

/**
 * Aperçu flou (16 px, ~200 octets) affiché instantanément pendant le chargement
 * de la photo. Généré par scripts/optimize-images.mjs.
 */
export function blurFor(src: string): `data:image/${string}` | "empty" {
  const data = (blurMap as Record<string, string>)[src];
  return data ? (data as `data:image/${string}`) : "empty";
}
