"use client";

import Image from "next/image";
import { blurFor } from "@/lib/blur";
import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useRef, useState } from "react";
import { RevealImage } from "@/components/motion";
import { cn } from "@/lib/cn";

type Img = { src: string; alt: string };

/** Galerie éditoriale + visionneuse plein écran (clavier, swipe, focus piégé). */
export function Gallery({ images, title }: { images: Img[]; title: string }) {
  const [open, setOpen] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastTrigger = useRef<HTMLElement | null>(null);

  const go = useCallback(
    (dir: 1 | -1) => setOpen((i) => (i === null ? i : (i + dir + images.length) % images.length)),
    [images.length],
  );

  useEffect(() => {
    if (open === null) return;
    document.documentElement.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.documentElement.style.overflow = "";
      window.removeEventListener("keydown", onKey);
      lastTrigger.current?.focus();
    };
  }, [open, go]);

  // Mise en page : alternance large / paire
  const layout = images.map((_, i) => {
    const m = i % 3;
    const alone = m === 1 && i === images.length - 1;
    return m === 0 || alone ? "md:col-span-12 aspect-[16/9]" : "md:col-span-6 aspect-[4/5]";
  });

  return (
    <>
      <ul className="grid gap-4 md:grid-cols-12 md:gap-6">
        {images.map((img, i) => (
          <li key={img.src + i} className={cn(layout[i], "relative")}>
            <button
              type="button"
              onClick={(e) => {
                lastTrigger.current = e.currentTarget;
                setOpen(i);
              }}
              className="group absolute inset-0 block w-full cursor-zoom-in"
              aria-label={`Agrandir la photo ${i + 1} sur ${images.length} : ${img.alt}`}
            >
              <RevealImage
                src={img.src}
                alt={img.alt}
                sizes={layout[i].includes("12") ? "(min-width:768px) 90vw, 100vw" : "(min-width:768px) 45vw, 100vw"}
                className="h-full w-full [&_img]:transition-transform [&_img]:duration-[1.4s] [&_img]:ease-[var(--ease-out-soft)] group-hover:[&_img]:scale-[1.03]"
              />
              <span className="numeral absolute bottom-4 left-4 text-sm text-chalk mix-blend-difference">
                {String(i + 1).padStart(2, "0")} / {String(images.length).padStart(2, "0")}
              </span>
            </button>
          </li>
        ))}
      </ul>

      <AnimatePresence>
        {open !== null && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={`Photos — ${title}`}
            className="fixed inset-0 z-[100] flex flex-col bg-ink text-chalk"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="flex items-center justify-between px-5 py-5 md:px-10">
              <p className="numeral text-sm">
                {String(open + 1).padStart(2, "0")} / {String(images.length).padStart(2, "0")}
              </p>
              <p className="hidden text-sm opacity-70 md:block">{title}</p>
              <button ref={closeRef} type="button" onClick={() => setOpen(null)} className="eyebrow link-underline pb-0.5">
                Fermer
              </button>
            </div>
            <div className="relative flex-1">
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.div
                  key={open}
                  className="absolute inset-0 mx-5 md:mx-24"
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.2}
                  onDragEnd={(_, info) => {
                    if (info.offset.x < -60) go(1);
                    else if (info.offset.x > 60) go(-1);
                  }}
                >
                  <Image src={images[open].src} placeholder={blurFor(images[open].src)} alt={images[open].alt} fill sizes="100vw" className="object-contain" draggable={false} />
                </motion.div>
              </AnimatePresence>
            </div>
            <div className="flex items-center justify-between px-5 py-6 md:px-10">
              <button type="button" onClick={() => go(-1)} className="eyebrow link-underline pb-0.5">
                ← Précédente
              </button>
              <p className="hidden max-w-md truncate text-sm opacity-60 sm:block">{images[open].alt}</p>
              <button type="button" onClick={() => go(1)} className="eyebrow link-underline pb-0.5">
                Suivante →
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
