"use client";

import Image from "next/image";
import { blurFor } from "@/lib/blur";
import Link from "next/link";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { LineReveal } from "@/components/motion";
import { PropertySearch } from "@/components/property-search";
import { agency } from "@/lib/agency";

const ease = [0.22, 1, 0.36, 1] as const;

export function HomeHero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section ref={ref} className="relative isolate flex min-h-[100svh] flex-col overflow-hidden bg-olive text-chalk">
      <motion.div className="absolute inset-0 -z-10" style={reduce ? undefined : { y: imgY }}>
        <motion.div
          className="absolute inset-0"
          initial={reduce ? false : { scale: 1.18 }}
          animate={{ scale: 1.04 }}
          transition={{ duration: 2.8, ease }}
        >
          <Image
            src="/images/hero.webp"
            placeholder={blurFor("/images/hero.webp")}
            alt="Villa contemporaine blanche, piscine et palmiers sous le ciel méditerranéen"
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
        </motion.div>
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgb(23_32_26/0.55)_0%,rgb(23_32_26/0.1)_38%,rgb(23_32_26/0.15)_60%,rgb(23_32_26/0.7)_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgb(23_32_26/0.55)_0%,rgb(23_32_26/0.2)_45%,transparent_70%)]" />
      </motion.div>

      {/* Rideau d'ouverture */}
      {!reduce && (
        <motion.div
          aria-hidden
          className="absolute inset-0 z-10 bg-chalk"
          initial={{ clipPath: "inset(0 0 0 0)" }}
          animate={{ clipPath: "inset(0 0 100% 0)" }}
          transition={{ duration: 1.1, ease: [0.65, 0, 0.35, 1], delay: 0.1 }}
        />
      )}

      <motion.div
        style={reduce ? undefined : { y: textY, opacity: fade }}
        className="mx-auto flex w-full max-w-[1600px] flex-1 flex-col justify-end px-5 pt-32 pb-10 md:px-10 md:pb-14"
      >
        <motion.p
          className="eyebrow mb-8 flex items-center gap-4"
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 0.85 }}
          transition={{ delay: 1.2, duration: 1 }}
        >
          <span className="h-px w-10 bg-current" />
          Agence immobilière — {agency.address.city}
        </motion.p>

        <LineReveal
          as="h1"
          immediate
          delay={0.85}
          className="font-display max-w-[14ch] text-[clamp(3rem,9vw,8.75rem)] leading-[0.92]"
          lines={[
            "L'immobilier",
            <>
              en toute <em className="italic text-sand">confiance.</em>
            </>,
          ]}
        />

        <div className="mt-10 grid gap-8 md:mt-14 md:grid-cols-12 md:items-end">
          <motion.p
            className="max-w-md text-[1.0625rem] leading-relaxed text-chalk/85 md:col-span-5"
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.45, duration: 1, ease }}
          >
            Achetez, vendez, louez avec sérénité. Villas, appartements et bureaux
            de Port El Kantaoui à Chott Mariem, accompagnés par une agence de proximité.
          </motion.p>
          <motion.div
            className="flex flex-wrap items-center gap-6 md:col-span-7 md:justify-end"
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.6, duration: 1, ease }}
          >
            <Link
              href="/biens"
              className="group inline-flex items-center gap-4 bg-chalk px-7 py-4 text-[0.75rem] tracking-[0.16em] text-ink uppercase transition-colors duration-300 hover:bg-sand"
            >
              Découvrir les biens
              <svg width="22" height="10" viewBox="0 0 22 10" fill="none" aria-hidden className="transition-transform duration-500 group-hover:translate-x-1">
                <path d="M0 5h20m0 0-4-4m4 4-4 4" stroke="currentColor" strokeWidth="1" />
              </svg>
            </Link>
            <span className="numeral hidden text-sm text-chalk/70 lg:inline">{agency.coordinatesLabel}</span>
          </motion.div>
        </div>
      </motion.div>

      <motion.div
        className="relative mx-auto w-full max-w-[1600px] px-0 md:px-10 md:pb-10"
        initial={reduce ? false : { opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.75, duration: 1.1, ease }}
      >
        <PropertySearch />
      </motion.div>
    </section>
  );
}
