import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Masque le badge « N » de développement (absent en production de toute façon)
  devIndicators: false,
  images: {
    // AVIF (le plus léger) puis WebP selon le navigateur ; mise en cache longue
    formats: ["image/avif", "image/webp"],
    minimumCacheTTL: 60 * 60 * 24 * 365,
    deviceSizes: [640, 828, 1080, 1440, 1920],
  },
  cacheComponents: true,
  partialPrefetching: true,
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
