// Animated "Neuro Noise" WebGL background.
// Adapted from Paper Shaders (https://shaders.paper.design/neuro-noise), Apache-2.0:
// https://github.com/paper-design/shaders
(function () {
  const FRAG = `// "Neuro Noise" — made with the 21st.dev Shader Builder
// Adapted from Paper Shaders: https://shaders.paper.design/neuro-noise
// Licensed under Apache-2.0: https://github.com/paper-design/shaders
// Packed WebGL1 uniforms (the shader exposes readable u_* aliases as macros):
// u_colors[8] (first 4 used)
// vec3(0.000, 0.000, 0.000)
// vec3(0.122, 0.318, 1.000)
// vec3(0.000, 0.898, 1.000)
// vec3(0.918, 0.992, 1.000)
// u_scene = vec4(canvas width, canvas height, seconds * 0.86, 4.0)
// u_shape = vec4(1.26, 0.35, 0.28, 0.00)
// u_surface = vec4(1.82, 1.00, -0.03, 1.48)
// u_finish = vec4(0.09, 0.00, 0.001, 0.10)
// u_transform = vec4(1.0, 0.00, 0.20, 0.0)
// u_space = vec4(0.00, 0.00, pointer x, pointer y)
// u_cursor = vec4(presence, 3.0, 0.45, 0.46)

#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform vec3 u_colors[8];
// Seven packed vectors + eight colour vectors = 15 fragment uniform vectors,
// one below WebGL1's guaranteed minimum. Macros preserve the public u_* API.
uniform vec4 u_scene; // resolution.xy, time, colour count
uniform vec4 u_shape; // scale, intensity, paramA, warp
uniform vec4 u_surface; // detail, contrast, brightness, saturation
uniform vec4 u_finish; // hue, vignette, blur, grain
uniform vec4 u_transform; // seed, rotation, drift, OKLab toggle
uniform vec4 u_space; // offset.xy, pointer.xy
uniform vec4 u_cursor;

#define u_resolution u_scene.xy
#define u_time u_scene.z
#define u_colorCount u_scene.w
#define u_scale u_shape.x
#define u_intensity u_shape.y
#define u_paramA u_shape.z
#define u_warp u_shape.w
#define u_detail u_surface.x
#define u_contrast u_surface.y
#define u_brightness u_surface.z
#define u_saturation u_surface.w
#define u_hue u_finish.x
#define u_vignette u_finish.y
#define u_blur u_finish.z
#define u_grain u_finish.w
#ifdef GL_FRAGMENT_PRECISION_HIGH
#define u_seed u_transform.x
#else
// Keep hash inputs inside mediump's guaranteed ±2^14 range.
#define u_seed mod(u_transform.x, 31.0)
#endif
#define u_rotate u_transform.y
#define u_drift u_transform.z
#define u_oklab u_transform.w
#define u_offset u_space.xy
#define u_mouse u_space.zw
#define u_cursorPresence u_cursor.x
#define u_cursorEffect u_cursor.y
#define u_cursorStrength u_cursor.z
#define u_cursorRadius u_cursor.w

float hash21(vec2 p) {
#ifndef GL_FRAGMENT_PRECISION_HIGH
p = mod(p, 31.0);
#endif
p = fract(p * vec2(234.34, 435.345));
p += dot(p, p + 34.23);
return fract(p.x * p.y);
}

// Even, un-structured white noise for film grain (Dave Hoskins hash12). The
// multiply hash above is fine for value noise but shows a faint axis-aligned
// mesh at integer fragment coords, which reads as a net over flat areas.
float grainHash(vec2 p) {
vec3 p3 = fract(vec3(p.xyx) * 0.1031);
p3 += dot(p3, p3.yzx + 33.33);
return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
#ifndef GL_FRAGMENT_PRECISION_HIGH
p = mod(p, 31.0);
#endif
float n = sin(dot(p, vec2(41.0, 289.0)));
return fract(vec2(15731.743, 7892.321) * n);
}

float noise(vec2 p) {
vec2 i = floor(p);
vec2 f = fract(p);
vec2 u = f * f * (3.0 - 2.0 * f);
return mix(
mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
u.y);
}

float fbm(vec2 p) {
float v = 0.0;
float a = 0.5;
for (int i = 0; i < 5; i++) {
v += a * noise(p);
p = p * 2.03 + vec2(17.0, 9.2);
a *= 0.5;
}
return v;
}

// --- OKLab colour mixing (perceptual), gated by u_oklab -----------------------
vec3 srgbToLinear(vec3 c) {
return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)),
step(0.04045, c));
}
vec3 linearToSrgb(vec3 c) {
// max() guards the sRGB branch: out-of-gamut OKLab interpolations can send a
// channel negative, and pow(negative, …) is NaN which mix()/step() would
// then propagate. The linear branch clips such channels to 0 downstream.
return mix(c * 12.92, 1.055 * pow(max(c, vec3(0.0)), vec3(1.0 / 2.4)) - 0.055,
step(0.0031308, c));
}
vec3 linToOklab(vec3 c) {
float l = 0.4122214708 * c.r + 0.5363325363 * c.g + 0.0514459929 * c.b;
float m = 0.2119034982 * c.r + 0.6806995451 * c.g + 0.1073969566 * c.b;
float s = 0.0883024619 * c.r + 0.2817188376 * c.g + 0.6299787005 * c.b;
l = pow(max(l, 0.0), 1.0 / 3.0);
m = pow(max(m, 0.0), 1.0 / 3.0);
s = pow(max(s, 0.0), 1.0 / 3.0);
return vec3(
0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s);
}
vec3 oklabToLin(vec3 c) {
float l = c.x + 0.3963377774 * c.y + 0.2158037573 * c.z;
float m = c.x - 0.1055613458 * c.y - 0.0638541728 * c.z;
float s = c.x - 0.0894841775 * c.y - 1.2914855480 * c.z;
l = l * l * l; m = m * m * m; s = s * s * s;
return vec3(
4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s);
}
vec3 mixColour(vec3 a, vec3 b, float t) {
if (u_oklab > 0.5) {
vec3 la = linToOklab(srgbToLinear(a));
vec3 lb = linToOklab(srgbToLinear(b));
return clamp(linearToSrgb(oklabToLin(mix(la, lb, t))), 0.0, 1.0);
}
return mix(a, b, t);
}

// Mix through the recipe colours; x is clamped to 0..1. WebGL1 forbids
// dynamic uniform indexing in fragment shaders, hence the constant loop.
vec3 palette(float x) {
float n = max(u_colorCount - 1.0, 1.0);
float f = clamp(x, 0.0, 1.0) * n;
vec3 col = u_colors[0];
for (int i = 0; i < 7; i++) {
if (float(i) < n)
col = mixColour(col, u_colors[i + 1],
smoothstep(0.0, 1.0, clamp(f - float(i), 0.0, 1.0)));
}
return col;
}

vec3 hueRotate(vec3 col, float a) {
const mat3 toYIQ = mat3(0.299, 0.596, 0.211,
0.587, -0.274, -0.523,
0.114, -0.322, 0.312);
const mat3 toRGB = mat3(1.0, 1.0, 1.0,
0.956, -0.272, -1.106,
0.621, -0.647, 1.703);
vec3 yiq = toYIQ * col;
float ca = cos(a), sa = sin(a);
yiq = vec3(yiq.x, yiq.y * ca - yiq.z * sa, yiq.y * sa + yiq.z * ca);
return toRGB * yiq;
}

vec3 shade(vec2 uv, vec2 p, float t) {
vec2 q = p * (1.6 + u_intensity * 2.4);
float field = 0.0;
float weight = 0.55;
for (int i = 0; i < 6; i++) {
float fi = float(i);
q += vec2(
sin(q.y * (1.7 + fi * 0.09) + t * (0.35 + fi * 0.04) + u_seed),
cos(q.x * (1.5 + fi * 0.11) - t * (0.28 + fi * 0.03))
) * (0.22 + u_intensity * 0.14);
float filaments = abs(sin(q.x + q.y + fi * 0.72));
field += weight / (0.08 + filaments);
weight *= 0.62;
q = q.yx * vec2(-1.08, 1.04);
}
float glow = 1.0 - exp(-field * (0.018 + u_paramA * 0.04));
return palette(clamp(glow, 0.0, 1.0));
}

void main() {
vec2 uv = gl_FragCoord.xy / u_resolution.xy;
vec2 screenUv = uv;
vec2 p = (gl_FragCoord.xy - 0.5 * u_resolution.xy)
/ min(u_resolution.x, u_resolution.y);
float cursorMask = 0.0;

// Cursor modes 1–3 are local distortions. Push shifts the same screen-space
// coordinates before field transforms, so Zoom/Rotate don't change its feel.
if (u_cursorPresence > 0.001) {
// u_mouse is normalized to -1..1 in canvas space. Convert it to the same
// aspect-corrected screen space as p so effects stay under the cursor.
vec2 cursor = (0.5 * u_mouse * u_resolution.xy)
/ min(u_resolution.x, u_resolution.y);
vec2 cursorDelta = p - cursor;
if (u_cursorEffect < 0.5) {
p += cursor * u_cursorPresence * u_cursorStrength * 0.55;
} else {
float cursorDistance = length(cursorDelta);
vec2 cursorDirection = cursorDelta / max(cursorDistance, 0.0001);
cursorMask = u_cursorPresence
* (1.0 - smoothstep(0.0, u_cursorRadius, cursorDistance));
if (u_cursorEffect < 1.5) {
p -= cursorDirection * cursorMask * u_cursorStrength * 0.24;
} else if (u_cursorEffect < 2.5) {
float cursorAngle = cursorMask * u_cursorStrength * 2.2;
float cc = cos(cursorAngle), cs = sin(cursorAngle);
p = cursor + mat2(cc, -cs, cs, cc) * cursorDelta;
} else if (u_cursorEffect < 3.5) {
float ripple = sin(
cursorDistance / max(u_cursorRadius, 0.001) * 18.0 - u_time * 5.0);
p -= cursorDirection * ripple * cursorMask * u_cursorStrength * 0.07;
}
}
}

// Keep presets that read uv (rather than p) in the same warped space.
uv = p * min(u_resolution.x, u_resolution.y) / u_resolution.xy + 0.5;
p *= u_scale;
// Field transform: rotate, pan, pointer push, slow drift.
if (abs(u_rotate) > 0.0001) {
float cr = cos(u_rotate), sr = sin(u_rotate);
p = mat2(cr, -sr, sr, cr) * p;
}
p += u_offset;
if (u_drift > 0.0001)
p += u_drift * vec2(sin(u_time * 0.31), cos(u_time * 0.23));
// Organic domain warp.
if (u_warp > 0.0) {
p += u_warp * (vec2(
fbm(p * u_detail + u_seed),
fbm(p * u_detail + vec2(5.2, 1.3))) - 0.5);
}
// Shade, with an optional soft 5-tap blur.
vec3 col;
if (u_blur > 0.0) {
float e = u_blur;
float pe = e * u_scale;
vec2 uvE = vec2(e) * min(u_resolution.x, u_resolution.y) / u_resolution.xy;
col = shade(uv, p, u_time) * 0.36;
col += shade(uv + vec2(uvE.x, 0.0), p + vec2(pe, 0.0), u_time) * 0.16;
col += shade(uv - vec2(uvE.x, 0.0), p - vec2(pe, 0.0), u_time) * 0.16;
col += shade(uv + vec2(0.0, uvE.y), p + vec2(0.0, pe), u_time) * 0.16;
col += shade(uv - vec2(0.0, uvE.y), p - vec2(0.0, pe), u_time) * 0.16;
} else {
col = shade(uv, p, u_time);
}
// Post: contrast, saturation, hue, brightness, vignette, grain.
if (abs(u_contrast - 1.0) > 0.0001)
col = (col - 0.5) * u_contrast + 0.5;
if (abs(u_saturation - 1.0) > 0.0001) {
float luma = dot(col, vec3(0.299, 0.587, 0.114));
col = mix(vec3(luma), col, u_saturation);
}
if (abs(u_hue) > 0.0001)
col = hueRotate(col, u_hue);
if (abs(u_brightness) > 0.0001)
col += u_brightness;
if (u_vignette > 0.0001) {
float vd = length(screenUv - 0.5) * 1.41421356;
col *= 1.0 - u_vignette * smoothstep(0.35, 1.0, vd);
}
if (u_cursorPresence > 0.001 && u_cursorEffect > 3.5)
col += (vec3(0.18) + col * 0.12) * cursorMask * u_cursorStrength;
if (u_grain > 0.0001)
col += (grainHash(
gl_FragCoord.xy + vec2(u_seed * 17.0, u_seed * 31.0)) - 0.5) * u_grain;
gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
`;

  const VERT = `attribute vec2 a_pos;
void main() { gl_Position = vec4(a_pos, 0.0, 1.0); }`;

  const canvas = document.createElement('canvas');
  canvas.className = 'shader-bg';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.prepend(canvas);

  const gl = canvas.getContext('webgl', { antialias: false, alpha: false, premultipliedAlpha: false });
  if (!gl) { canvas.remove(); return; }

  function compile(type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      console.error('Neuro Noise shader:', gl.getShaderInfoLog(s));
      return null;
    }
    return s;
  }
  const vs = compile(gl.VERTEX_SHADER, VERT);
  const fs = compile(gl.FRAGMENT_SHADER, FRAG);
  if (!vs || !fs) { canvas.remove(); return; }
  const prog = gl.createProgram();
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
    console.error('Neuro Noise link:', gl.getProgramInfoLog(prog));
    canvas.remove(); return;
  }
  gl.useProgram(prog);

  // Fullscreen triangle
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const aPos = gl.getAttribLocation(prog, 'a_pos');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

  const U = (n) => gl.getUniformLocation(prog, n);
  const uColors = U('u_colors'), uScene = U('u_scene'), uShape = U('u_shape'),
    uSurface = U('u_surface'), uFinish = U('u_finish'), uTransform = U('u_transform'),
    uSpace = U('u_space'), uCursor = U('u_cursor');

  // Static uniforms, exactly as in the shader header
  const colors = new Float32Array(24);
  colors.set([0.000, 0.000, 0.000, 0.122, 0.318, 1.000, 0.000, 0.898, 1.000, 0.918, 0.992, 1.000]);
  gl.uniform3fv(uColors, colors);
  gl.uniform4f(uShape, 1.26, 0.35, 0.28, 0.00);
  gl.uniform4f(uSurface, 1.82, 1.00, -0.03, 1.48);
  gl.uniform4f(uFinish, 0.09, 0.00, 0.001, 0.10);
  gl.uniform4f(uTransform, 1.0, 0.00, 0.20, 0.0);

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(canvas.clientWidth * dpr));
    const h = Math.max(1, Math.round(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w; canvas.height = h;
      gl.viewport(0, 0, w, h);
    }
  }

  // Pointer in -1..1 canvas space (y up, matching gl_FragCoord)
  const pointer = { x: 0, y: 0, tx: 0, ty: 0, presence: 0, target: 0 };
  window.addEventListener('pointermove', (e) => {
    const r = canvas.getBoundingClientRect();
    pointer.tx = ((e.clientX - r.left) / r.width) * 2 - 1;
    pointer.ty = 1 - ((e.clientY - r.top) / r.height) * 2;
    if (pointer.target === 0) { pointer.x = pointer.tx; pointer.y = pointer.ty; }
    pointer.target = 1;
  }, { passive: true });
  document.addEventListener('pointerleave', () => { pointer.target = 0; });
  window.addEventListener('blur', () => { pointer.target = 0; });

  let raf = 0, last = performance.now(), seconds = 0;
  function frame(now) {
    const dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    seconds += dt;
    resize();
    const k = 1 - Math.exp(-dt * 8);
    pointer.x += (pointer.tx - pointer.x) * k;
    pointer.y += (pointer.ty - pointer.y) * k;
    pointer.presence += (pointer.target - pointer.presence) * (1 - Math.exp(-dt * 4));
    gl.uniform4f(uScene, canvas.width, canvas.height, seconds * 0.86, 4.0);
    gl.uniform4f(uSpace, 0.00, 0.00, pointer.x, pointer.y);
    gl.uniform4f(uCursor, pointer.presence, 3.0, 0.45, 0.46);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    raf = requestAnimationFrame(frame);
  }
  function start() { if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } }
  function stop() { cancelAnimationFrame(raf); raf = 0; }

  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
  canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); stop(); });
  if (!document.hidden) start();
})();
